# RN0 · Primeros pasos con React Native + Expo

Dos proyectos de la cursada, con la identidad de **BurgosCorp** (rojo, negro y gris) y modo claro/oscuro.

| Carpeta | Actividad |
|---|---|
| [`rn1-hola-mundo`](rn1-hola-mundo) | **1.** Primer proyecto con Expo: pantalla limpia con un “¡Hola, mundo!” y un nuevo tab con estilos diferentes. |
| [`rn2-componentes`](rn2-componentes) | **2.** Proyecto en TypeScript que muestra todos los componentes nativos de React Native, para qué se usan y una demo en vivo de cada uno. |

## Cómo correr cualquiera de los dos

```bash
cd rn1-hola-mundo   # o rn2-componentes
npm install
npx expo start      # o: npx expo start --tunnel
```

Escaneá el QR con **Expo Go**. Cada carpeta tiene su propio README con el detalle y la solución a problemas de conexión.

**Stack:** Expo SDK 57 · React Native 0.86 · React 19 · TypeScript · Expo Router

Documentación: [docs.expo.dev](https://docs.expo.dev/)
