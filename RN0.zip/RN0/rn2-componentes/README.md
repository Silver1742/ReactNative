# RN2 · Catálogo de componentes nativos de React Native

App en **Expo + TypeScript** que muestra **todos los componentes del core de React Native** (y sus APIs), explica **para qué se usa cada uno** y trae una **demo en vivo** de cada uno. Diseño BurgosCorp (rojo, negro y gris) con modo claro/oscuro.

## Qué incluye

- **24 componentes** agrupados por categoría: básicos, interfaz, listas, táctiles, feedback, contenedores especiales, solo Android y solo iOS.
- **15 APIs** (StyleSheet, Alert, Animated, Platform, Linking, Share, Vibration…), porque en la práctica van de la mano con los componentes.
- Cada ficha tiene: **qué es**, **para qué se usa** + casos de uso, **demo en vivo**, **props clave**, **ejemplo de código**, plataformas soportadas, avisos (deprecado / alternativa recomendada) y link a la documentación oficial.
- **Buscador** (ignora tildes y mayúsculas) y **filtro por plataforma**.
- Navegación **anterior / siguiente** entre fichas.

| Pestaña | Contenido |
|---|---|
| **Componentes** | `SectionList` agrupada por categoría con buscador y filtros |
| **APIs** | Misma pantalla reutilizada con las APIs |
| **Acerca** | Estadísticas, selector de tema, diferencia componente/API, cómo correrlo |

### Componentes cubiertos

`View` · `Text` · `Image` · `ImageBackground` · `TextInput` · `ScrollView` · `Button` · `Switch` · `FlatList` · `SectionList` · `VirtualizedList` · `Pressable` · `TouchableOpacity` · `TouchableHighlight` · `TouchableWithoutFeedback` · `ActivityIndicator` · `Modal` · `RefreshControl` · `StatusBar` · `KeyboardAvoidingView` · `SafeAreaView` · `DrawerLayoutAndroid` · `TouchableNativeFeedback` · `InputAccessoryView`

### APIs cubiertas

`StyleSheet` · `Alert` · `Animated` · `useWindowDimensions` · `Platform` · `useColorScheme` · `Keyboard` · `Linking` · `Share` · `Vibration` · `PixelRatio` · `AccessibilityInfo` · `BackHandler` · `ToastAndroid` · `ActionSheetIOS`

## Cómo correrlo

```bash
npm install
npx expo start
```

- **Celular:** abrí **Expo Go** y escaneá el QR. Es la forma de ver las demos exclusivas (`DrawerLayoutAndroid`, `ToastAndroid` en Android; `InputAccessoryView`, `ActionSheetIOS` en iOS).
- **Web:** apretá `w`. Los componentes que no existen en web muestran un aviso en lugar de la demo.

### Si el celular no conecta

- El celu y la PC tienen que estar en la **misma red Wi-Fi**, marcada como **privada** en Windows, y Node.js tiene que estar **permitido** en el firewall para redes privadas.
- Si el router aísla a los dispositivos entre sí (pasa en muchos routers de fibra), usá el modo túnel. `@expo/ngrok` ya está instalado en el proyecto:

```bash
npx expo start --tunnel
```

- Si Expo Go muestra *"Failed to download remote update"* en la primera carga, tocá **recargar**: es un timeout mientras se arma la app por primera vez.

Verificar tipos: `npm run typecheck`.

## Estructura

```
src/
├── app/                      # Rutas (Expo Router)
│   ├── _layout.tsx           # Providers + Stack raíz
│   ├── (tabs)/               # Grupo de pestañas
│   │   ├── _layout.tsx
│   │   ├── index.tsx         # Componentes
│   │   ├── apis.tsx          # APIs
│   │   └── acerca.tsx
│   └── detalle/[id].tsx      # Ficha de cada componente/API (ruta dinámica)
├── data/                     # Catálogo tipado (la "base de datos" de la app)
│   ├── types.ts              # CatalogEntry, Category, PropDoc…
│   ├── components.ts
│   ├── apis.ts
│   └── index.ts              # Categorías, búsqueda, agrupado, vecinos
├── demos/                    # Una demo en vivo por ficha
│   ├── index.ts              # Registro id → demo
│   ├── plataforma.tsx        # Respaldo web (aviso "solo Android/iOS")
│   ├── plataforma.android.tsx
│   └── plataforma.ios.tsx
├── components/               # UI reutilizable (Card, Chip, Badge, CodeBlock, CatalogScreen…)
└── theme/                    # Tokens + ThemeContext (claro / oscuro / sistema)
```

## Decisiones técnicas

- **Datos separados de la UI:** todo el contenido vive en `src/data` con el tipo `CatalogEntry`; las pantallas solo lo renderizan. Agregar un componente nuevo = una entrada en el array + una demo en `DEMOS`.
- **Archivos por plataforma:** Metro elige `plataforma.android.tsx`, `plataforma.ios.tsx` o `plataforma.tsx` según dónde corre la app, así nunca se importa un componente que no existe en esa plataforma (por ejemplo `DrawerLayoutAndroid` en iOS o web).
- **Ruta dinámica** `detalle/[id]` con un `key` por ficha, para que el estado de cada demo se reinicie al pasar de una a otra.
- **`SafeAreaView` de `react-native-safe-area-context`**, no el del core (deprecado y solo iOS) — la propia ficha lo explica.
- **TypeScript `strict`** y rutas tipadas de Expo Router (`typedRoutes`).

Documentación: [docs.expo.dev](https://docs.expo.dev/) · [reactnative.dev/docs/components-and-apis](https://reactnative.dev/docs/components-and-apis)
