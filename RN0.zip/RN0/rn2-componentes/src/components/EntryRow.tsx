import { useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Icon } from './Icon';
import { Badge } from './ui';

import { PLATFORM_LABEL, type CatalogEntry } from '@/data';
import { Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Muestra "iOS · Android · Web" solo si el componente NO está en las tres plataformas. */
export function PlatformBadges({ entry }: { entry: CatalogEntry }) {
  const isEverywhere = entry.platforms.length === 3;
  return (
    <View style={badgeStyles.row}>
      {entry.deprecated && <Badge label="Deprecado" tone="warning" />}
      {isEverywhere ? (
        <Badge label="iOS · Android · Web" tone="success" />
      ) : (
        entry.platforms.map((platform) => <Badge key={platform} label={`Solo ${PLATFORM_LABEL[platform]}`} tone="primary" />)
      )}
    </View>
  );
}

const badgeStyles = StyleSheet.create({
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs },
});

/** Fila de la lista principal: nombre, resumen y plataformas. Navega al detalle. */
export function EntryRow({ entry }: { entry: CatalogEntry }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const router = useRouter();

  return (
    <Pressable
      onPress={() => router.push({ pathname: '/detalle/[id]', params: { id: entry.id } })}
      accessibilityRole="link"
      accessibilityHint={`Abre la ficha de ${entry.name}`}
      style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.surfaceMuted }]}>
      <View style={styles.monogram}>
        <Text style={styles.monogramText}>{entry.name.replace(/^use/, '').slice(0, 2)}</Text>
      </View>
      <View style={styles.body}>
        <Text style={styles.name}>{entry.name}</Text>
        <Text style={styles.summary} numberOfLines={2}>
          {entry.summary}
        </Text>
        {(entry.platforms.length < 3 || entry.deprecated) && (
          <View style={styles.badges}>
            <PlatformBadges entry={entry} />
          </View>
        )}
      </View>
      <Icon name={{ ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }} color={colors.textSubtle} size={18} />
    </Pressable>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.md,
      paddingHorizontal: Spacing.lg,
      paddingVertical: Spacing.md,
      backgroundColor: c.surface,
    },
    monogram: {
      width: 42,
      height: 42,
      borderRadius: Radius.md,
      backgroundColor: c.primarySoft,
      alignItems: 'center',
      justifyContent: 'center',
    },
    monogramText: { color: c.primaryText, fontWeight: '800', fontSize: 15 },
    body: { flex: 1, gap: 2 },
    name: { color: c.text, fontSize: 16, fontWeight: '700' },
    summary: { color: c.textMuted, fontSize: 13.5, lineHeight: 19 },
    badges: { marginTop: Spacing.xs },
  });
