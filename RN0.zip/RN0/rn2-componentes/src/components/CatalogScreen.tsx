import { useMemo, useState } from 'react';
import { SectionList, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from './BrandLogo';
import { EntryRow } from './EntryRow';
import { Icon } from './Icon';
import { ThemeToggle } from './ThemeToggle';
import { Chip } from './ui';

import { groupByCategory, matchesQuery, PLATFORM_LABEL, type CatalogEntry, type Platform } from '@/data';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

type PlatformFilter = 'todas' | Platform;
const FILTERS: PlatformFilter[] = ['todas', 'android', 'ios', 'web'];

type CatalogScreenProps = {
  title: string;
  kicker: string;
  description: string;
  entries: CatalogEntry[];
};

/**
 * Pantalla de listado reutilizada por las pestañas "Componentes" y "APIs":
 * buscador + filtro por plataforma + SectionList agrupada por categoría.
 */
export function CatalogScreen({ title, kicker, description, entries }: CatalogScreenProps) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [query, setQuery] = useState('');
  const [platform, setPlatform] = useState<PlatformFilter>('todas');

  const sections = useMemo(
    () =>
      groupByCategory(
        entries.filter(
          (entry) => matchesQuery(entry, query) && (platform === 'todas' || entry.platforms.includes(platform)),
        ),
      ),
    [entries, query, platform],
  );
  const visibleCount = sections.reduce((total, section) => total + section.data.length, 0);

  const header = (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <BrandLogo size={30} withName />
        <ThemeToggle />
      </View>
      <Text style={styles.kicker}>{kicker}</Text>
      <Text style={styles.title} accessibilityRole="header">
        {title}
      </Text>
      <Text style={styles.description}>{description}</Text>

      <View style={styles.search}>
        <Icon name={{ ios: 'magnifyingglass', android: 'search', web: 'search' }} color={colors.textSubtle} size={18} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Buscar por nombre o para qué sirve…"
          placeholderTextColor={colors.textSubtle}
          style={styles.searchInput}
          autoCorrect={false}
          autoCapitalize="none"
          clearButtonMode="while-editing"
          returnKeyType="search"
          accessibilityLabel="Buscar"
        />
      </View>

      <View style={styles.filters}>
        {FILTERS.map((filter) => (
          <Chip
            key={filter}
            label={filter === 'todas' ? 'Todas' : PLATFORM_LABEL[filter]}
            selected={platform === filter}
            onPress={() => setPlatform(filter)}
          />
        ))}
      </View>
      <Text style={styles.count}>
        {visibleCount} de {entries.length}
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <SectionList
        sections={sections}
        keyExtractor={(entry) => entry.id}
        renderItem={({ item, index, section }) => (
          <View
            style={[
              styles.itemWrapper,
              index === 0 && styles.itemFirst,
              index === section.data.length - 1 && styles.itemLast,
            ]}>
            {index > 0 && <View style={styles.separator} />}
            <EntryRow entry={item} />
          </View>
        )}
        renderSectionHeader={({ section }) => (
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <Text style={styles.sectionDescription}>{section.description}</Text>
          </View>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>Sin resultados</Text>
            <Text style={styles.emptyBody}>Probá con otra palabra o quitá el filtro de plataforma.</Text>
          </View>
        }
        stickySectionHeadersEnabled={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    listContent: {
      paddingHorizontal: Spacing.lg,
      paddingBottom: Spacing.xxl,
      width: '100%',
      maxWidth: MaxContentWidth,
      alignSelf: 'center',
    },

    header: { paddingTop: Spacing.md, gap: Spacing.sm },
    headerTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.sm },
    kicker: { color: c.primary, fontSize: 12, fontWeight: '800', letterSpacing: 2 },
    title: { color: c.text, fontSize: 30, fontWeight: '800', letterSpacing: -0.5 },
    description: { color: c.textMuted, fontSize: 15, lineHeight: 21 },

    search: {
      marginTop: Spacing.sm,
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.sm,
      paddingHorizontal: Spacing.md,
      borderRadius: Radius.md,
      backgroundColor: c.surface,
      borderWidth: 1,
      borderColor: c.border,
    },
    searchInput: { flex: 1, paddingVertical: Spacing.md - 2, color: c.text, fontSize: 15 },
    filters: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    count: { color: c.textSubtle, fontSize: 12, fontFamily: Fonts.mono },

    sectionHeader: { paddingTop: Spacing.xl, paddingBottom: Spacing.sm },
    sectionTitle: { color: c.text, fontSize: 13, fontWeight: '800', letterSpacing: 1.2, textTransform: 'uppercase' },
    sectionDescription: { color: c.textSubtle, fontSize: 13, marginTop: 2 },

    itemWrapper: {
      backgroundColor: c.surface,
      borderLeftWidth: StyleSheet.hairlineWidth,
      borderRightWidth: StyleSheet.hairlineWidth,
      borderColor: c.border,
      overflow: 'hidden',
    },
    itemFirst: { borderTopWidth: StyleSheet.hairlineWidth, borderTopLeftRadius: Radius.lg, borderTopRightRadius: Radius.lg },
    itemLast: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomLeftRadius: Radius.lg, borderBottomRightRadius: Radius.lg },
    separator: { height: StyleSheet.hairlineWidth, backgroundColor: c.border, marginLeft: Spacing.lg + 42 + Spacing.md },

    empty: { alignItems: 'center', paddingVertical: Spacing.xxxl, gap: Spacing.xs },
    emptyTitle: { color: c.text, fontSize: 17, fontWeight: '700' },
    emptyBody: { color: c.textMuted, fontSize: 14, textAlign: 'center' },
  });
