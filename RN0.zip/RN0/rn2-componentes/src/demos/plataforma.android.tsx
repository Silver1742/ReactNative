import { useRef, useState } from 'react';
import { DrawerLayoutAndroid, Text, ToastAndroid, TouchableNativeFeedback, View } from 'react-native';

import { AppButton } from '@/components/ui';
import { DemoCaption, DemoUnavailable, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

export function DrawerLayoutAndroidDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const drawer = useRef<DrawerLayoutAndroid>(null);
  const [section, setSection] = useState('Inicio');

  const menu = () => (
    <View style={{ flex: 1, backgroundColor: colors.inverse, padding: Spacing.lg, gap: Spacing.md }}>
      <Text style={{ color: colors.primary, fontWeight: '800', letterSpacing: 1 }}>MENÚ</Text>
      {['Inicio', 'Perfil', 'Ajustes'].map((item) => (
        <Text
          key={item}
          style={{ color: colors.onInverse, fontSize: 16 }}
          onPress={() => {
            setSection(item);
            drawer.current?.closeDrawer();
          }}>
          {item}
        </Text>
      ))}
    </View>
  );

  return (
    <View style={{ height: 220, borderRadius: Radius.md, overflow: 'hidden' }}>
      <DrawerLayoutAndroid ref={drawer} drawerWidth={180} drawerPosition="left" renderNavigationView={menu}>
        <View style={[s.surface, s.stack, { flex: 1, justifyContent: 'center' }]}>
          <Text style={s.strong}>Sección: {section}</Text>
          <AppButton label="Abrir menú" onPress={() => drawer.current?.openDrawer()} />
          <DemoCaption>También se abre deslizando desde el borde izquierdo de esta caja.</DemoCaption>
        </View>
      </DrawerLayoutAndroid>
    </View>
  );
}

export function TouchableNativeFeedbackDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [taps, setTaps] = useState(0);
  return (
    <View style={s.stack}>
      <View style={{ borderRadius: Radius.md, overflow: 'hidden' }}>
        <TouchableNativeFeedback background={TouchableNativeFeedback.Ripple('rgba(255,255,255,0.35)', false)} onPress={() => setTaps((n) => n + 1)}>
          <View style={{ backgroundColor: colors.primary, padding: Spacing.lg, alignItems: 'center' }}>
            <Text style={{ color: colors.onPrimary, fontWeight: '800' }}>Tocame (ripple) · {taps}</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
    </View>
  );
}

export function InputAccessoryViewDemo() {
  return <DemoUnavailable platform="iOS" />;
}

export function ToastAndroidDemo() {
  const s = useDemoStyles();
  return (
    <View style={s.stack}>
      <AppButton label="Toast corto" onPress={() => ToastAndroid.show('Tarea guardada', ToastAndroid.SHORT)} />
      <AppButton variant="outline" label="Toast largo" onPress={() => ToastAndroid.show('Copiado al portapapeles', ToastAndroid.LONG)} />
    </View>
  );
}

export function ActionSheetIOSDemo() {
  return <DemoUnavailable platform="iOS" />;
}
