import { useState } from 'react';
import { ActionSheetIOS, Button, InputAccessoryView, Keyboard, Text, TextInput, View } from 'react-native';

import { AppButton } from '@/components/ui';

import { DemoCaption, DemoUnavailable, useDemoStyles } from './shared';

import { Spacing, useAppTheme } from '@/theme';

const ACCESSORY_ID = 'demo-accessory';

export function DrawerLayoutAndroidDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function TouchableNativeFeedbackDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function InputAccessoryViewDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [amount, setAmount] = useState('');
  return (
    <View style={s.stack}>
      <TextInput
        value={amount}
        onChangeText={setAmount}
        keyboardType="number-pad"
        placeholder="Monto (teclado numérico)"
        placeholderTextColor={colors.textSubtle}
        style={s.input}
        inputAccessoryViewID={ACCESSORY_ID}
      />
      <DemoCaption>El teclado numérico de iOS no tiene "Listo": la barra de arriba lo agrega.</DemoCaption>
      <InputAccessoryView nativeID={ACCESSORY_ID} backgroundColor={colors.surfaceMuted}>
        <View style={{ alignItems: 'flex-end', paddingHorizontal: Spacing.md }}>
          <Button title="Listo" color={colors.primary} onPress={Keyboard.dismiss} />
        </View>
      </InputAccessoryView>
    </View>
  );
}

export function ToastAndroidDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function ActionSheetIOSDemo() {
  const s = useDemoStyles();
  const [choice, setChoice] = useState('Sin elegir.');
  const open = () =>
    ActionSheetIOS.showActionSheetWithOptions(
      { options: ['Cancelar', 'Editar', 'Compartir', 'Eliminar'], cancelButtonIndex: 0, destructiveButtonIndex: 3 },
      (index) => setChoice(['Cancelaste', 'Editar', 'Compartir', 'Eliminar'][index] ?? '—'),
    );
  return (
    <View style={s.stack}>
      <AppButton label="Abrir hoja de acciones" onPress={open} />
      <Text style={s.muted}>{choice}</Text>
    </View>
  );
}
