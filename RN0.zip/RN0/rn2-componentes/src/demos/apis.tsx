import { useEffect, useRef, useState } from 'react';
import {
  AccessibilityInfo,
  Alert,
  Animated,
  BackHandler,
  Keyboard,
  Linking,
  PixelRatio,
  Platform,
  Share,
  StyleSheet,
  Text,
  TextInput,
  useColorScheme,
  useWindowDimensions,
  Vibration,
  View,
} from 'react-native';

import { AppButton } from '@/components/ui';
import { DemoCaption, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

/** Fila "clave: valor" para mostrar datos que devuelve una API. */
function Stat({ label, value }: { label: string; value: string }) {
  const s = useDemoStyles();
  return (
    <View style={[s.row, { justifyContent: 'space-between' }]}>
      <Text style={s.muted}>{label}</Text>
      <Text style={s.strong}>{value}</Text>
    </View>
  );
}

export function StyleSheetDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <View style={s.stack}>
      <View style={{ height: 80, borderRadius: Radius.md, backgroundColor: colors.surfaceMuted }}>
        <View style={[StyleSheet.absoluteFill, { margin: Spacing.md, borderRadius: Radius.sm, borderWidth: 2, borderColor: colors.primary }]} />
      </View>
      <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: colors.text }} />
      <DemoCaption>{`Arriba: StyleSheet.absoluteFill con margen. Línea: hairlineWidth = ${StyleSheet.hairlineWidth.toFixed(3)} pt.`}</DemoCaption>
    </View>
  );
}

export function AlertDemo() {
  const s = useDemoStyles();
  const [answer, setAnswer] = useState('Sin respuesta todavía.');
  const ask = () =>
    Alert.alert('Eliminar tarea', '¿Seguro que querés eliminarla?', [
      { text: 'Cancelar', style: 'cancel', onPress: () => setAnswer('Elegiste: Cancelar') },
      { text: 'Eliminar', style: 'destructive', onPress: () => setAnswer('Elegiste: Eliminar') },
    ]);
  return (
    <View style={s.stack}>
      <AppButton label="Mostrar Alert" onPress={ask} />
      <Text style={s.muted}>{answer}</Text>
    </View>
  );
}

export function AnimatedDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const scale = useRef(new Animated.Value(1)).current;
  const rotate = useRef(new Animated.Value(0)).current;

  const bounce = () => {
    rotate.setValue(0);
    Animated.parallel([
      Animated.sequence([
        Animated.spring(scale, { toValue: 1.35, useNativeDriver: Platform.OS !== 'web' }),
        Animated.spring(scale, { toValue: 1, friction: 3, useNativeDriver: Platform.OS !== 'web' }),
      ]),
      Animated.timing(rotate, { toValue: 1, duration: 600, useNativeDriver: Platform.OS !== 'web' }),
    ]).start();
  };

  const spin = rotate.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  return (
    <View style={[s.stack, { alignItems: 'center' }]}>
      <Animated.View
        style={{
          width: 72,
          height: 72,
          borderRadius: Radius.lg,
          backgroundColor: colors.primary,
          transform: [{ scale }, { rotate: spin }],
        }}
      />
      <AppButton label="Animar (spring + timing)" onPress={bounce} />
    </View>
  );
}

export function DimensionsDemo() {
  const s = useDemoStyles();
  const { width, height, scale, fontScale } = useWindowDimensions();
  return (
    <View style={[s.surface, { gap: Spacing.xs }]}>
      <Stat label="Ancho" value={`${Math.round(width)} pt`} />
      <Stat label="Alto" value={`${Math.round(height)} pt`} />
      <Stat label="Escala de píxeles" value={`${scale}x`} />
      <Stat label="Escala de fuente" value={`${fontScale}x`} />
      <Stat label="Layout sugerido" value={width >= 700 ? 'Tablet / escritorio' : 'Celular'} />
      <DemoCaption>Rotá el teléfono o cambiá el tamaño de la ventana: los valores se actualizan solos.</DemoCaption>
    </View>
  );
}

export function PlatformDemo() {
  const s = useDemoStyles();
  return (
    <View style={[s.surface, { gap: Spacing.xs }]}>
      <Stat label="Platform.OS" value={Platform.OS} />
      <Stat label="Platform.Version" value={String(Platform.Version ?? '—')} />
      <Stat
        label="Platform.select(…)"
        value={Platform.select({ ios: 'Estoy en iOS 🍎', android: 'Estoy en Android 🤖', default: 'Estoy en la web 🌐' })}
      />
    </View>
  );
}

export function AppearanceDemo() {
  const s = useDemoStyles();
  const system = useColorScheme();
  const { scheme, preference } = useAppTheme();
  return (
    <View style={[s.surface, { gap: Spacing.xs }]}>
      <Stat label="Sistema (useColorScheme)" value={system ?? 'sin preferencia'} />
      <Stat label="Preferencia en la app" value={preference} />
      <Stat label="Tema que se pinta" value={scheme} />
      <DemoCaption>Cambiá el modo con el botón de la pestaña "Acerca" o desde el sistema operativo.</DemoCaption>
    </View>
  );
}

export function KeyboardDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => setOpen(true));
    const hide = Keyboard.addListener('keyboardDidHide', () => setOpen(false));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  return (
    <View style={s.stack}>
      <TextInput placeholder="Tocá para abrir el teclado" placeholderTextColor={colors.textSubtle} style={s.input} />
      <Text style={s.strong}>Teclado: {open ? 'abierto' : 'cerrado'}</Text>
      <AppButton variant="outline" label="Keyboard.dismiss()" onPress={Keyboard.dismiss} />
    </View>
  );
}

export function LinkingDemo() {
  const s = useDemoStyles();
  const [error, setError] = useState<string | null>(null);
  const open = (url: string) => Linking.openURL(url).catch(() => setError(`No hay una app que pueda abrir ${url}`));
  return (
    <View style={s.stack}>
      <AppButton label="Abrir docs.expo.dev" onPress={() => open('https://docs.expo.dev')} />
      <AppButton variant="outline" label="Abrir reactnative.dev" onPress={() => open('https://reactnative.dev')} />
      {error && <Text style={s.muted}>{error}</Text>}
    </View>
  );
}

export function ShareDemo() {
  const s = useDemoStyles();
  const [result, setResult] = useState('');
  const share = async () => {
    try {
      const outcome = await Share.share({ message: 'Catálogo de componentes de React Native · BurgosCorp' });
      setResult(outcome.action === Share.sharedAction ? 'Compartido ✔' : 'Cerraste el diálogo.');
    } catch {
      setResult('Este navegador no soporta compartir (Web Share API).');
    }
  };
  return (
    <View style={s.stack}>
      <AppButton label="Compartir" onPress={share} />
      {!!result && <Text style={s.muted}>{result}</Text>}
    </View>
  );
}

export function VibrationDemo() {
  const s = useDemoStyles();
  return (
    <View style={s.stack}>
      <AppButton label="Vibrar una vez" onPress={() => Vibration.vibrate()} />
      <AppButton variant="outline" label="Patrón: corto-pausa-largo" onPress={() => Vibration.vibrate([0, 120, 120, 400])} />
      <DemoCaption>Solo en un dispositivo físico (en iOS el patrón usa pausas fijas de 1 s).</DemoCaption>
    </View>
  );
}

export function PixelRatioDemo() {
  const s = useDemoStyles();
  return (
    <View style={[s.surface, { gap: Spacing.xs }]}>
      <Stat label="PixelRatio.get()" value={`${PixelRatio.get()}`} />
      <Stat label="getFontScale()" value={`${PixelRatio.getFontScale()}`} />
      <Stat label="120 dp en píxeles físicos" value={`${PixelRatio.getPixelSizeForLayoutSize(120)} px`} />
    </View>
  );
}

export function AccessibilityInfoDemo() {
  const s = useDemoStyles();
  const [reader, setReader] = useState<boolean | null>(null);
  const [reduceMotion, setReduceMotion] = useState<boolean | null>(null);

  useEffect(() => {
    AccessibilityInfo.isScreenReaderEnabled().then(setReader).catch(() => setReader(null));
    AccessibilityInfo.isReduceMotionEnabled().then(setReduceMotion).catch(() => setReduceMotion(null));
  }, []);

  const yesNo = (value: boolean | null) => (value === null ? '—' : value ? 'Sí' : 'No');

  return (
    <View style={s.stack}>
      <View style={[s.surface, { gap: Spacing.xs }]}>
        <Stat label="Lector de pantalla" value={yesNo(reader)} />
        <Stat label="Reducir movimiento" value={yesNo(reduceMotion)} />
      </View>
      <AppButton
        variant="outline"
        label="Anunciar un mensaje"
        onPress={() => AccessibilityInfo.announceForAccessibility('Hola desde el catálogo de React Native')}
      />
      <DemoCaption>El anuncio solo se escucha con TalkBack o VoiceOver activado.</DemoCaption>
    </View>
  );
}

export function BackHandlerDemo() {
  const s = useDemoStyles();
  const [blocked, setBlocked] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!blocked) return;
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      setMessage('Interceptado: el "atrás" no salió de la pantalla.');
      return true; // true = "ya lo manejé", cancela la navegación por defecto
    });
    return () => subscription.remove();
  }, [blocked]);

  if (Platform.OS !== 'android') {
    return <DemoCaption>BackHandler solo tiene efecto en Android (botón o gesto "atrás").</DemoCaption>;
  }

  return (
    <View style={s.stack}>
      <AppButton
        variant={blocked ? 'solid' : 'outline'}
        label={blocked ? 'Interceptando "atrás" (tocar para soltar)' : 'Interceptar el botón "atrás"'}
        onPress={() => {
          setBlocked((v) => !v);
          setMessage('');
        }}
      />
      {!!message && <Text style={s.muted}>{message}</Text>}
    </View>
  );
}
