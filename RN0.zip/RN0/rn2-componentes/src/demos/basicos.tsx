import { useState } from 'react';
import { Image, ImageBackground, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { DemoCaption, SAMPLE_IMAGE, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

export function ViewDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <View style={s.stack}>
      <DemoCaption>Tres Views en fila con flex 1, 2 y 1: se reparten el ancho en esa proporción.</DemoCaption>
      <View style={{ flexDirection: 'row', gap: Spacing.sm }}>
        <View style={[s.box, { flex: 1, height: 56, backgroundColor: colors.primary }]} />
        <View style={[s.box, { flex: 2, height: 56, backgroundColor: colors.inverse }]} />
        <View style={[s.box, { flex: 1, height: 56, backgroundColor: colors.textSubtle }]} />
      </View>
    </View>
  );
}

export function TextDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [expanded, setExpanded] = useState(false);
  return (
    <View style={s.stack}>
      <Text style={s.text}>
        Texto normal, <Text style={{ fontWeight: '800' }}>negrita anidada</Text> y{' '}
        <Text style={{ color: colors.primary, textDecorationLine: 'underline' }} onPress={() => setExpanded((v) => !v)}>
          un link tocable
        </Text>
        .
      </Text>
      <Text style={s.muted} numberOfLines={expanded ? undefined : 2}>
        Este párrafo usa numberOfLines={'{2}'}: cuando el texto es más largo que dos líneas se corta con puntos suspensivos.
        Tocá el link de arriba para expandirlo y ver el texto completo, que sigue y sigue para demostrar el truncado.
      </Text>
      <Text style={s.muted} selectable>
        Este texto es selectable: mantenelo presionado para copiarlo.
      </Text>
    </View>
  );
}

export function ImageDemo() {
  const s = useDemoStyles();
  const [status, setStatus] = useState('Cargando…');
  return (
    <View style={s.stack}>
      <View style={s.row}>
        <Image
          source={{ uri: SAMPLE_IMAGE }}
          style={{ width: 96, height: 96, borderRadius: 48 }}
          resizeMode="cover"
          onLoad={() => setStatus('onLoad: imagen cargada ✔')}
          onError={() => setStatus('onError: no se pudo cargar (¿sin conexión?)')}
          accessibilityLabel="Foto de ejemplo"
        />
        <Image source={{ uri: SAMPLE_IMAGE }} style={{ width: 96, height: 96, borderRadius: Radius.md }} blurRadius={6} />
      </View>
      <DemoCaption>{`Remota con borderRadius circular y otra con blurRadius. Estado: ${status}`}</DemoCaption>
    </View>
  );
}

export function ImageBackgroundDemo() {
  return (
    <ImageBackground
      source={{ uri: SAMPLE_IMAGE }}
      style={styles.cover}
      imageStyle={{ borderRadius: Radius.lg }}
      resizeMode="cover">
      <View style={styles.coverOverlay}>
        <Text style={styles.coverKicker}>IMAGEBACKGROUND</Text>
        <Text style={styles.coverTitle}>Texto encima de una foto</Text>
      </View>
    </ImageBackground>
  );
}

export function TextInputDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  return (
    <View style={s.stack}>
      <TextInput
        value={name}
        onChangeText={setName}
        placeholder="Tu nombre"
        placeholderTextColor={colors.textSubtle}
        style={s.input}
        autoCapitalize="words"
        returnKeyType="next"
      />
      <TextInput
        value={password}
        onChangeText={setPassword}
        placeholder="Contraseña (secureTextEntry)"
        placeholderTextColor={colors.textSubtle}
        style={s.input}
        secureTextEntry
      />
      <Text style={s.text}>
        {name ? `¡Hola, ${name}!` : 'Escribí tu nombre…'} {password && `· contraseña de ${password.length} caracteres`}
      </Text>
    </View>
  );
}

export function ScrollViewDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <View style={s.stack}>
      <DemoCaption>ScrollView horizontal: deslizá las tarjetas hacia los costados.</DemoCaption>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.sm }}>
        {Array.from({ length: 10 }, (_, index) => (
          <View
            key={index}
            style={[s.box, { width: 92, height: 92, backgroundColor: index % 2 ? colors.inverse : colors.primary }]}>
            <Text style={{ color: index % 2 ? colors.onInverse : colors.onPrimary, fontWeight: '800', fontSize: 20 }}>
              {index + 1}
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  cover: { height: 170, justifyContent: 'flex-end' },
  coverOverlay: {
    padding: Spacing.lg,
    borderBottomLeftRadius: Radius.lg,
    borderBottomRightRadius: Radius.lg,
    backgroundColor: 'rgba(0, 0, 0, 0.55)',
  },
  coverKicker: { color: '#ef3b4f', fontSize: 11, fontWeight: '800', letterSpacing: 2 },
  coverTitle: { color: '#ffffff', fontSize: 20, fontWeight: '800' },
});
