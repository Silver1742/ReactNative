import { useState } from 'react';
import {
  Button,
  Keyboard,
  Pressable,
  Switch,
  Text,
  TextInput,
  TouchableHighlight,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';

import { DemoCaption, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

export function ButtonDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [count, setCount] = useState(0);
  return (
    <View style={s.stack}>
      <Button title={`Tocado ${count} veces`} color={colors.primary} onPress={() => setCount((n) => n + 1)} />
      <Button title="Deshabilitado" disabled onPress={() => {}} />
      <DemoCaption>El aspecto depende de la plataforma: en iOS es solo texto, en Android un botón con fondo.</DemoCaption>
    </View>
  );
}

export function SwitchDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [notifications, setNotifications] = useState(true);
  const [wifiOnly, setWifiOnly] = useState(false);
  const rows: [string, boolean, (value: boolean) => void][] = [
    ['Notificaciones', notifications, setNotifications],
    ['Descargar solo con Wi-Fi', wifiOnly, setWifiOnly],
  ];
  return (
    <View style={s.stack}>
      {rows.map(([label, value, onChange]) => (
        <View key={label} style={[s.row, { justifyContent: 'space-between' }]}>
          <Text style={s.text}>{label}</Text>
          <Switch
            value={value}
            onValueChange={onChange}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor="#ffffff"
            accessibilityLabel={label}
          />
        </View>
      ))}
    </View>
  );
}

export function PressableDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [log, setLog] = useState('Probá tocar y mantener presionado.');
  return (
    <View style={s.stack}>
      <Pressable
        onPress={() => setLog('onPress: toque corto')}
        onLongPress={() => setLog('onLongPress: lo mantuviste presionado')}
        android_ripple={{ color: 'rgba(255,255,255,0.3)' }}
        hitSlop={10}
        style={({ pressed }) => ({
          backgroundColor: pressed ? colors.primaryPressed : colors.primary,
          transform: [{ scale: pressed ? 0.96 : 1 }],
          padding: Spacing.lg,
          borderRadius: Radius.md,
          alignItems: 'center',
        })}>
        {({ pressed }) => (
          <Text style={{ color: colors.onPrimary, fontWeight: '800' }}>{pressed ? '¡Presionado!' : 'Pressable'}</Text>
        )}
      </Pressable>
      <Text style={s.muted}>{log}</Text>
    </View>
  );
}

export function TouchableOpacityDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [likes, setLikes] = useState(0);
  return (
    <View style={s.row}>
      <TouchableOpacity
        activeOpacity={0.5}
        onPress={() => setLikes((n) => n + 1)}
        style={{ backgroundColor: colors.inverse, paddingVertical: Spacing.md, paddingHorizontal: Spacing.xl, borderRadius: Radius.md }}>
        <Text style={{ color: colors.onInverse, fontWeight: '700' }}>♥ Me gusta</Text>
      </TouchableOpacity>
      <Text style={s.text}>{likes} likes</Text>
    </View>
  );
}

export function TouchableHighlightDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <View style={{ borderRadius: Radius.md, overflow: 'hidden' }}>
      {['Perfil', 'Ajustes', 'Cerrar sesión'].map((item, index) => (
        <View key={item}>
          {index > 0 && <View style={s.separator} />}
          <TouchableHighlight underlayColor={colors.primarySoft} onPress={() => setSelected(item)}>
            <View style={s.listItem}>
              <Text style={[s.text, selected === item && { color: colors.primary, fontWeight: '700' }]}>{item}</Text>
            </View>
          </TouchableHighlight>
        </View>
      ))}
    </View>
  );
}

export function TouchableWithoutFeedbackDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [taps, setTaps] = useState(0);
  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
        setTaps((n) => n + 1);
      }}
      accessible={false}>
      <View style={[s.surface, s.stack]}>
        <TextInput placeholder="Escribí algo y tocá el fondo gris" placeholderTextColor={colors.textSubtle} style={s.input} />
        <DemoCaption>{`Tocar la zona gris cierra el teclado (Keyboard.dismiss). Toques en el fondo: ${taps}`}</DemoCaption>
      </View>
    </TouchableWithoutFeedback>
  );
}
