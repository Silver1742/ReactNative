/**
 * Demos de componentes exclusivos de una plataforma.
 * Metro elige el archivo según la plataforma: plataforma.android.tsx, plataforma.ios.tsx
 * y este (.tsx) como respaldo para web. Así nunca se importa un componente que no existe.
 */
import { DemoUnavailable } from './shared';

export function DrawerLayoutAndroidDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function TouchableNativeFeedbackDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function InputAccessoryViewDemo() {
  return <DemoUnavailable platform="iOS" />;
}

export function ToastAndroidDemo() {
  return <DemoUnavailable platform="Android" />;
}

export function ActionSheetIOSDemo() {
  return <DemoUnavailable platform="iOS" />;
}
