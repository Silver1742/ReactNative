import { useState } from 'react';
import { FlatList, SectionList, Text, View, VirtualizedList } from 'react-native';

import { AppButton } from '@/components/ui';
import { DemoCaption, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

type Task = { id: number; title: string };

const LIST_HEIGHT = 220;

export function FlatListDemo() {
  const s = useDemoStyles();
  const [tasks, setTasks] = useState<Task[]>(() =>
    Array.from({ length: 20 }, (_, index) => ({ id: index + 1, title: `Tarea #${index + 1}` })),
  );

  const loadMore = () =>
    setTasks((current) => [
      ...current,
      ...Array.from({ length: 10 }, (_, index) => ({ id: current.length + index + 1, title: `Tarea #${current.length + index + 1}` })),
    ]);

  return (
    <View style={s.stack}>
      <DemoCaption>{`${tasks.length} ítems. Al llegar al final, onEndReached carga 10 más (scroll infinito).`}</DemoCaption>
      <FlatList
        data={tasks}
        keyExtractor={(task) => String(task.id)}
        renderItem={({ item }) => (
          <View style={s.listItem}>
            <Text style={s.text}>{item.title}</Text>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={s.separator} />}
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        nestedScrollEnabled
        style={{ height: LIST_HEIGHT, borderRadius: Radius.md }}
      />
    </View>
  );
}

const CONTACTS = [
  { title: 'A', data: ['Ana', 'Andrés', 'Agustina'] },
  { title: 'B', data: ['Belén', 'Bruno'] },
  { title: 'C', data: ['Camila', 'Carlos', 'Cecilia'] },
  { title: 'M', data: ['Martina', 'Mateo'] },
  { title: 'U', data: ['Uriel'] },
];

export function SectionListDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <SectionList
      sections={CONTACTS}
      keyExtractor={(item) => item}
      renderItem={({ item }) => (
        <View style={s.listItem}>
          <Text style={s.text}>{item}</Text>
        </View>
      )}
      renderSectionHeader={({ section }) => (
        <View style={{ backgroundColor: colors.primary, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs }}>
          <Text style={{ color: colors.onPrimary, fontWeight: '800' }}>{section.title}</Text>
        </View>
      )}
      stickySectionHeadersEnabled
      nestedScrollEnabled
      style={{ height: LIST_HEIGHT, borderRadius: Radius.md }}
    />
  );
}

type Row = { id: string; label: string };

export function VirtualizedListDemo() {
  const s = useDemoStyles();
  const [total, setTotal] = useState(1000);
  return (
    <View style={s.stack}>
      <DemoCaption>{`No hay ningún array: getItem calcula la fila N al vuelo. Filas: ${total.toLocaleString('es-AR')}`}</DemoCaption>
      <VirtualizedList<Row>
        getItemCount={() => total}
        getItem={(_, index) => ({ id: String(index), label: `Fila ${index + 1} de ${total}` })}
        keyExtractor={(row) => row.id}
        renderItem={({ item }) => (
          <View style={s.listItem}>
            <Text style={s.text}>{item.label}</Text>
          </View>
        )}
        ItemSeparatorComponent={() => <View style={s.separator} />}
        initialNumToRender={12}
        nestedScrollEnabled
        style={{ height: LIST_HEIGHT, borderRadius: Radius.md }}
      />
      <AppButton variant="outline" label="Probar con 1.000.000 de filas" onPress={() => setTotal(1_000_000)} />
    </View>
  );
}
