import { StyleSheet, Text, View } from 'react-native';

import { Icon } from '@/components/Icon';
import { Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Imagen remota de ejemplo (Picsum entrega fotos libres, siempre la misma por "seed"). */
export const SAMPLE_IMAGE = 'https://picsum.photos/seed/burgoscorp/600/400';

/** Para componentes que no existen en la plataforma donde está corriendo la app. */
export function DemoUnavailable({ platform }: { platform: string }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <View style={styles.box}>
      <Icon name={{ ios: 'iphone.slash', android: 'phonelink_off', web: 'phonelink_off' }} color={colors.textSubtle} size={28} />
      <Text style={styles.title}>Disponible solo en {platform}</Text>
      <Text style={styles.body}>
        Abrí la app en un dispositivo {platform} con Expo Go (escaneando el QR de `npx expo start`) para ver la demo en vivo.
      </Text>
    </View>
  );
}

/** Texto chico que explica qué mirar en la demo. */
export function DemoCaption({ children }: { children: string }) {
  const { colors } = useAppTheme();
  return <Text style={{ color: colors.textMuted, fontSize: 13, lineHeight: 18 }}>{children}</Text>;
}

/** Hook con estilos comunes de las demos (cajas de color, textos). */
export function useDemoStyles() {
  return useThemedStyles(createDemoStyles);
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    box: {
      alignItems: 'center',
      gap: Spacing.sm,
      padding: Spacing.xl,
      borderRadius: Radius.md,
      borderWidth: 1,
      borderStyle: 'dashed',
      borderColor: c.border,
    },
    title: { color: c.text, fontWeight: '700', fontSize: 15 },
    body: { color: c.textMuted, fontSize: 13, textAlign: 'center', lineHeight: 18 },
  });

const createDemoStyles = (c: ThemeColors) =>
  StyleSheet.create({
    stack: { gap: Spacing.md },
    row: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flexWrap: 'wrap' },
    text: { color: c.text, fontSize: 15 },
    muted: { color: c.textMuted, fontSize: 13 },
    strong: { color: c.text, fontSize: 15, fontWeight: '700' },
    box: { borderRadius: Radius.sm, alignItems: 'center', justifyContent: 'center' },
    surface: { backgroundColor: c.surfaceMuted, borderRadius: Radius.md, padding: Spacing.md },
    input: {
      borderWidth: 1,
      borderColor: c.border,
      borderRadius: Radius.md,
      paddingHorizontal: Spacing.md,
      paddingVertical: Spacing.sm + 2,
      color: c.text,
      backgroundColor: c.surface,
      fontSize: 15,
    },
    listItem: { paddingVertical: Spacing.sm + 2, paddingHorizontal: Spacing.md, backgroundColor: c.surfaceMuted },
    separator: { height: StyleSheet.hairlineWidth, backgroundColor: c.border },
  });
