import { useState } from 'react';
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { AppButton } from '@/components/ui';
import { DemoCaption, useDemoStyles } from './shared';

import { Radius, Spacing, useAppTheme } from '@/theme';

export function ActivityIndicatorDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [loading, setLoading] = useState(false);

  const simulateFetch = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 2000);
  };

  return (
    <View style={s.stack}>
      <View style={s.row}>
        <ActivityIndicator size="small" color={colors.primary} />
        <ActivityIndicator size="large" color={colors.primary} />
        <ActivityIndicator size="large" color={colors.textSubtle} />
      </View>
      <AppButton label={loading ? 'Cargando…' : 'Simular pedido a la API (2 s)'} onPress={simulateFetch} disabled={loading} />
      {loading && <ActivityIndicator accessibilityLabel="Cargando" color={colors.primary} />}
    </View>
  );
}

export function ModalDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [visible, setVisible] = useState(false);
  const [result, setResult] = useState('Todavía no abriste el modal.');

  const close = (message: string) => {
    setVisible(false);
    setResult(message);
  };

  return (
    <View style={s.stack}>
      <AppButton label="Abrir modal de confirmación" onPress={() => setVisible(true)} />
      <Text style={s.muted}>{result}</Text>
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => close('Cerrado con "atrás".')}>
        <Pressable style={styles.overlay} onPress={() => close('Cerrado tocando el fondo.')}>
          {/* El Pressable interno frena el toque para que no cierre al tocar la tarjeta. */}
          <Pressable style={[styles.dialog, { backgroundColor: colors.surface }]} onPress={() => {}}>
            <Text style={[s.strong, { fontSize: 18 }]}>¿Eliminar la tarea?</Text>
            <Text style={s.muted}>Esta acción no se puede deshacer.</Text>
            <View style={[s.row, { justifyContent: 'flex-end' }]}>
              <AppButton variant="outline" label="Cancelar" onPress={() => close('Cancelaste.')} />
              <AppButton label="Eliminar" onPress={() => close('Confirmaste: tarea eliminada.')} />
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

export function RefreshControlDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [updatedAt, setUpdatedAt] = useState(() => new Date());

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setUpdatedAt(new Date());
      setRefreshing(false);
    }, 1200);
  };

  return (
    <View style={s.stack}>
      <DemoCaption>
        {Platform.OS === 'web'
          ? 'En web no existe el gesto: usá el botón para simularlo.'
          : 'Arrastrá la caja hacia abajo para refrescar.'}
      </DemoCaption>
      <ScrollView
        style={[s.surface, { height: 140 }]}
        contentContainerStyle={{ flexGrow: 1, alignItems: 'center', justifyContent: 'center' }}
        nestedScrollEnabled
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[colors.primary]} tintColor={colors.primary} />
        }>
        <Text style={s.strong}>Última actualización</Text>
        <Text style={s.muted}>{updatedAt.toLocaleTimeString('es-AR')}</Text>
      </ScrollView>
      {Platform.OS === 'web' && <AppButton variant="outline" label="Refrescar" onPress={onRefresh} disabled={refreshing} />}
    </View>
  );
}

export function StatusBarDemo() {
  const s = useDemoStyles();
  const [hidden, setHidden] = useState(false);
  return (
    <View style={s.stack}>
      {/* Solo mientras esta demo está montada: al salir, expo-status-bar vuelve a mandar. */}
      <StatusBar hidden={hidden} animated />
      <AppButton variant="outline" label={hidden ? 'Mostrar barra de estado' : 'Ocultar barra de estado'} onPress={() => setHidden((v) => !v)} />
      <DemoCaption>Mirá la parte superior del teléfono (hora, batería). En web no hay barra de estado.</DemoCaption>
    </View>
  );
}

export function KeyboardAvoidingViewDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={100}>
      <View style={[s.surface, s.stack]}>
        <DemoCaption>Tocá el input: el contenedor se ajusta para que el teclado no lo tape.</DemoCaption>
        <TextInput placeholder="Escribí un mensaje…" placeholderTextColor={colors.textSubtle} style={s.input} />
      </View>
    </KeyboardAvoidingView>
  );
}

export function SafeAreaViewDemo() {
  const s = useDemoStyles();
  const { colors } = useAppTheme();
  return (
    <View style={[s.stack]}>
      <View style={{ borderRadius: Radius.md, overflow: 'hidden', borderWidth: 2, borderColor: colors.primary }}>
        <SafeAreaView edges={['left', 'right']} style={{ backgroundColor: colors.primarySoft, padding: Spacing.md }}>
          <Text style={s.text}>Contenido dentro de SafeAreaView (react-native-safe-area-context).</Text>
        </SafeAreaView>
      </View>
      <DemoCaption>Esta misma app usa SafeAreaView en todas sus pantallas para respetar el notch y la barra de gestos.</DemoCaption>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.55)', justifyContent: 'center', padding: Spacing.xl },
  dialog: { borderRadius: Radius.lg, padding: Spacing.xl, gap: Spacing.md, maxWidth: 420, width: '100%', alignSelf: 'center' },
});
