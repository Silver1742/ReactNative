import type { ComponentType } from 'react';

import * as Apis from './apis';
import * as Basicos from './basicos';
import * as Feedback from './feedback';
import * as Interaccion from './interaccion';
import * as Listas from './listas';
import * as Plataforma from './plataforma';

/** Demo en vivo de cada ficha, indexada por el id del catálogo (src/data). */
export const DEMOS: Record<string, ComponentType> = {
  // Componentes
  view: Basicos.ViewDemo,
  text: Basicos.TextDemo,
  image: Basicos.ImageDemo,
  imagebackground: Basicos.ImageBackgroundDemo,
  textinput: Basicos.TextInputDemo,
  scrollview: Basicos.ScrollViewDemo,
  button: Interaccion.ButtonDemo,
  switch: Interaccion.SwitchDemo,
  flatlist: Listas.FlatListDemo,
  sectionlist: Listas.SectionListDemo,
  virtualizedlist: Listas.VirtualizedListDemo,
  pressable: Interaccion.PressableDemo,
  touchableopacity: Interaccion.TouchableOpacityDemo,
  touchablehighlight: Interaccion.TouchableHighlightDemo,
  touchablewithoutfeedback: Interaccion.TouchableWithoutFeedbackDemo,
  activityindicator: Feedback.ActivityIndicatorDemo,
  modal: Feedback.ModalDemo,
  refreshcontrol: Feedback.RefreshControlDemo,
  statusbar: Feedback.StatusBarDemo,
  keyboardavoidingview: Feedback.KeyboardAvoidingViewDemo,
  safeareaview: Feedback.SafeAreaViewDemo,
  drawerlayoutandroid: Plataforma.DrawerLayoutAndroidDemo,
  touchablenativefeedback: Plataforma.TouchableNativeFeedbackDemo,
  inputaccessoryview: Plataforma.InputAccessoryViewDemo,

  // APIs
  stylesheet: Apis.StyleSheetDemo,
  alert: Apis.AlertDemo,
  animated: Apis.AnimatedDemo,
  dimensions: Apis.DimensionsDemo,
  platform: Apis.PlatformDemo,
  appearance: Apis.AppearanceDemo,
  keyboard: Apis.KeyboardDemo,
  linking: Apis.LinkingDemo,
  share: Apis.ShareDemo,
  vibration: Apis.VibrationDemo,
  pixelratio: Apis.PixelRatioDemo,
  accessibilityinfo: Apis.AccessibilityInfoDemo,
  backhandler: Apis.BackHandlerDemo,
  toastandroid: Plataforma.ToastAndroidDemo,
  actionsheetios: Plataforma.ActionSheetIOSDemo,
};
