import { Linking, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from '@/components/BrandLogo';
import { AppButton, Card, Chip, CodeBlock } from '@/components/ui';
import { APIS, COMPONENTS } from '@/data';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors, type ThemePreference } from '@/theme';

const THEME_OPTIONS: { value: ThemePreference; label: string }[] = [
  { value: 'system', label: 'Sistema' },
  { value: 'light', label: 'Claro' },
  { value: 'dark', label: 'Oscuro' },
];

const exclusive = [...COMPONENTS, ...APIS].filter((entry) => entry.platforms.length < 3).length;

export default function AcercaScreen() {
  const styles = useThemedStyles(createStyles);
  const { preference, setPreference } = useAppTheme();

  const stats = [
    { value: COMPONENTS.length, label: 'Componentes' },
    { value: APIS.length, label: 'APIs' },
    { value: exclusive, label: 'De una sola plataforma' },
  ];

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.column}>
          <View style={styles.brand}>
            <BrandLogo size={64} />
            <Text style={styles.title}>Catálogo React Native</Text>
            <Text style={styles.subtitle}>Expo · TypeScript · Expo Router</Text>
          </View>

          <View style={styles.stats}>
            {stats.map((stat) => (
              <View key={stat.label} style={styles.stat}>
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>

          <Card title="Apariencia" icon={{ ios: 'circle.lefthalf.filled', android: 'contrast', web: 'contrast' }}>
            <View style={styles.row}>
              {THEME_OPTIONS.map((option) => (
                <Chip
                  key={option.value}
                  label={option.label}
                  selected={preference === option.value}
                  onPress={() => setPreference(option.value)}
                />
              ))}
            </View>
          </Card>

          <Card title="¿Componente o API?" icon={{ ios: 'questionmark.circle.fill', android: 'help', web: 'help' }}>
            <Text style={styles.paragraph}>
              Un <Text style={styles.strong}>componente</Text> se escribe como JSX y dibuja algo en pantalla (
              <Text style={styles.code}>{'<View>'}</Text>, <Text style={styles.code}>{'<FlatList>'}</Text>). React Native
              lo convierte en el widget nativo de cada sistema: no es una web dentro de la app.
            </Text>
            <Text style={styles.paragraph}>
              Una <Text style={styles.strong}>API</Text> es un módulo de funciones que habla con el sistema operativo (
              <Text style={styles.code}>Alert.alert()</Text>, <Text style={styles.code}>Vibration.vibrate()</Text>).
            </Text>
          </Card>

          <Card title="Correrlo en tu celular" icon={{ ios: 'iphone', android: 'smartphone', web: 'smartphone' }}>
            <Text style={styles.paragraph}>
              Instalá Expo Go, corré el proyecto y escaneá el QR. Las demos “solo Android” o “solo iOS” se ven en ese
              dispositivo.
            </Text>
            <CodeBlock code={'npm install\nnpx expo start'} />
          </Card>

          <AppButton
            label="Documentación de Expo"
            icon={{ ios: 'book.fill', android: 'menu_book', web: 'menu_book' }}
            onPress={() => Linking.openURL('https://docs.expo.dev/')}
          />
          <AppButton
            variant="outline"
            label="Componentes en reactnative.dev"
            icon={{ ios: 'arrow.up.right.square', android: 'open_in_new', web: 'open_in_new' }}
            onPress={() => Linking.openURL('https://reactnative.dev/docs/components-and-apis')}
          />
          <Text style={styles.footer}>BurgosCorp · Uriel Burgos</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },
    brand: { alignItems: 'center', gap: Spacing.xs, paddingVertical: Spacing.lg },
    title: { color: c.text, fontSize: 26, fontWeight: '800', marginTop: Spacing.sm },
    subtitle: { color: c.textMuted, fontSize: 14, fontFamily: Fonts.mono },

    stats: { flexDirection: 'row', gap: Spacing.sm },
    stat: {
      flex: 1,
      alignItems: 'center',
      paddingVertical: Spacing.lg,
      paddingHorizontal: Spacing.xs,
      borderRadius: Radius.lg,
      backgroundColor: c.surface,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: c.border,
    },
    statValue: { color: c.primary, fontSize: 28, fontWeight: '800' },
    statLabel: { color: c.textMuted, fontSize: 12, textAlign: 'center' },

    row: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
    paragraph: { color: c.text, fontSize: 15, lineHeight: 22 },
    strong: { fontWeight: '800' },
    code: { fontFamily: Fonts.mono, color: c.primary, fontSize: 13.5 },
    footer: { color: c.textSubtle, fontSize: 12, textAlign: 'center' },
  });
