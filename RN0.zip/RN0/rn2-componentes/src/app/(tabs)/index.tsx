import { CatalogScreen } from '@/components/CatalogScreen';
import { COMPONENTS } from '@/data';

export default function ComponentesScreen() {
  return (
    <CatalogScreen
      kicker="REACT NATIVE · CORE"
      title="Componentes nativos"
      description="Todos los componentes del paquete react-native: qué son, para qué se usan y una demo en vivo de cada uno."
      entries={COMPONENTS}
    />
  );
}
