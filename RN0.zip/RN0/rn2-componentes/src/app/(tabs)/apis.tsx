import { CatalogScreen } from '@/components/CatalogScreen';
import { APIS } from '@/data';

export default function ApisScreen() {
  return (
    <CatalogScreen
      kicker="REACT NATIVE · APIS"
      title="APIs nativas"
      description="No dibujan nada: exponen funciones del sistema (alertas, vibración, dimensiones, animaciones…) a JavaScript."
      entries={APIS}
    />
  );
}
