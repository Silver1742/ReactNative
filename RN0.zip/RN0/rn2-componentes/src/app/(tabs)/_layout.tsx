import { Tabs } from 'expo-router/js-tabs';

import { Icon } from '@/components/Icon';
import { useAppTheme } from '@/theme';

export default function TabsLayout() {
  const { colors } = useAppTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSubtle,
        tabBarLabelStyle: { fontWeight: '600' },
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Componentes',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'square.grid.2x2.fill', android: 'widgets', web: 'widgets' }} color={color} size={size} />
          ),
        }}
      />
      <Tabs.Screen
        name="apis"
        options={{
          title: 'APIs',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'curlybraces', android: 'data_object', web: 'data_object' }} color={color} size={size} />
          ),
        }}
      />
      <Tabs.Screen
        name="acerca"
        options={{
          title: 'Acerca',
          tabBarIcon: ({ color, size }) => (
            <Icon name={{ ios: 'info.circle.fill', android: 'info', web: 'info' }} color={color} size={size} />
          ),
        }}
      />
    </Tabs>
  );
}
