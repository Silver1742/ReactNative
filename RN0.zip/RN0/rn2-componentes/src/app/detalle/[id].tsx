import { Link, Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { PlatformBadges } from '@/components/EntryRow';
import { Icon } from '@/components/Icon';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AppButton, Card, CodeBlock, Notice } from '@/components/ui';
import { getCategory, getEntry, getNeighbors, type CatalogEntry } from '@/data';
import { DEMOS } from '@/demos';
import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

/** Ficha de un componente o API: qué es, para qué sirve, demo en vivo, props y código. */
export default function DetalleScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const entry = getEntry(id);
  const styles = useThemedStyles(createStyles);

  if (!entry) {
    return (
      <View style={styles.notFound}>
        <Stack.Screen options={{ title: 'No encontrado' }} />
        <Text style={styles.title}>No existe “{id}”</Text>
        <Link href="/" style={styles.link}>
          Volver al catálogo
        </Link>
      </View>
    );
  }

  // El `key` reinicia el estado de la demo al pasar de una ficha a otra con "anterior / siguiente".
  return <EntryDetail key={entry.id} entry={entry} />;
}

function EntryDetail({ entry }: { entry: CatalogEntry }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const Demo = DEMOS[entry.id];
  const category = getCategory(entry.category);
  const { previous, next } = getNeighbors(entry);

  return (
    <SafeAreaView style={styles.safeArea} edges={['left', 'right', 'bottom']}>
      <Stack.Screen options={{ title: entry.name, headerRight: () => <ThemeToggle /> }} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.column}>
          {/* Encabezado */}
          <View style={styles.hero}>
            <View style={styles.heroStripe} />
            <Text style={styles.heroKicker}>
              {entry.kind === 'api' ? 'API' : 'COMPONENTE'} · {category.title.toUpperCase()}
            </Text>
            <Text style={styles.heroTitle}>{`<${entry.name} />`.replace(/^<(use\w+) \/>$/, '$1()')}</Text>
            <Text style={styles.heroSummary}>{entry.summary}</Text>
            <PlatformBadges entry={entry} />
          </View>

          {entry.note && <Notice tone={entry.deprecated ? 'warning' : 'info'}>{entry.note}</Notice>}

          <Card title="¿Para qué se usa?" icon={{ ios: 'lightbulb.fill', android: 'lightbulb', web: 'lightbulb' }}>
            <Text style={styles.paragraph}>{entry.purpose}</Text>
            <View style={styles.bullets}>
              {entry.useCases.map((useCase) => (
                <View key={useCase} style={styles.bulletRow}>
                  <View style={styles.bulletDot} />
                  <Text style={styles.bulletText}>{useCase}</Text>
                </View>
              ))}
            </View>
          </Card>

          {Demo && (
            <Card
              title="Demo en vivo"
              icon={{ ios: 'play.circle.fill', android: 'play_circle', web: 'play_circle' }}
              style={styles.demoCard}>
              <Demo />
            </Card>
          )}

          <Card title={entry.kind === 'api' ? 'Métodos y valores clave' : 'Props clave'} icon={{ ios: 'slider.horizontal.3', android: 'tune', web: 'tune' }}>
            {entry.props.map((prop, index) => (
              <View key={prop.name} style={[styles.prop, index > 0 && styles.propDivider]}>
                <Text style={styles.propName}>{prop.name}</Text>
                <Text style={styles.propType}>{prop.type}</Text>
                <Text style={styles.propDescription}>{prop.description}</Text>
              </View>
            ))}
          </Card>

          <Card title="Ejemplo de código" icon={{ ios: 'chevron.left.forwardslash.chevron.right', android: 'code', web: 'code' }}>
            <CodeBlock code={entry.snippet} />
          </Card>

          <AppButton
            variant="outline"
            label="Documentación oficial"
            icon={{ ios: 'arrow.up.right.square', android: 'open_in_new', web: 'open_in_new' }}
            onPress={() => Linking.openURL(entry.docsUrl)}
          />

          {/* Navegación anterior / siguiente */}
          <View style={styles.pager}>
            {previous ? <PagerLink entry={previous} direction="previous" /> : <View style={styles.pagerSpacer} />}
            {next ? <PagerLink entry={next} direction="next" /> : <View style={styles.pagerSpacer} />}
          </View>
          <Text style={[styles.footer, { color: colors.textSubtle }]}>Fuente: reactnative.dev · docs.expo.dev</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function PagerLink({ entry, direction }: { entry: CatalogEntry; direction: 'previous' | 'next' }) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const router = useRouter();
  const isNext = direction === 'next';

  return (
    <Pressable
      onPress={() => router.replace({ pathname: '/detalle/[id]', params: { id: entry.id } })}
      accessibilityRole="link"
      style={({ pressed }) => [styles.pagerItem, isNext && styles.pagerItemNext, pressed && { backgroundColor: colors.surfaceMuted }]}>
      <Text style={styles.pagerLabel}>{isNext ? 'Siguiente' : 'Anterior'}</Text>
      <View style={[styles.pagerRow, isNext && { flexDirection: 'row-reverse' }]}>
        <Icon
          name={
            isNext
              ? { ios: 'chevron.right', android: 'chevron_right', web: 'chevron_right' }
              : { ios: 'chevron.left', android: 'chevron_left', web: 'chevron_left' }
          }
          color={colors.primary}
          size={16}
        />
        <Text style={styles.pagerName} numberOfLines={1}>
          {entry.name}
        </Text>
      </View>
    </Pressable>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },

    hero: {
      overflow: 'hidden',
      borderRadius: Radius.xl,
      padding: Spacing.xl,
      paddingLeft: Spacing.xl + Spacing.sm,
      backgroundColor: '#111111',
      experimental_backgroundImage: 'linear-gradient(135deg, #2e2e33 0%, #050505 100%)',
      gap: Spacing.sm,
    },
    heroStripe: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 6, backgroundColor: '#e11d2e' },
    heroKicker: { color: '#ef3b4f', fontSize: 11, fontWeight: '800', letterSpacing: 2 },
    heroTitle: { color: '#ffffff', fontSize: 26, fontWeight: '800', fontFamily: Fonts.mono },
    heroSummary: { color: '#d4d4d8', fontSize: 15, lineHeight: 22, marginBottom: Spacing.xs },

    paragraph: { color: c.text, fontSize: 15, lineHeight: 22 },
    bullets: { gap: Spacing.sm },
    bulletRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start' },
    bulletDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: c.primary, marginTop: 8 },
    bulletText: { flex: 1, color: c.textMuted, fontSize: 14.5, lineHeight: 21 },

    demoCard: { borderColor: c.primary, borderWidth: 1.5 },

    prop: { gap: 2, paddingVertical: Spacing.xs },
    propDivider: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: c.border, paddingTop: Spacing.sm + 2 },
    propName: { color: c.primary, fontFamily: Fonts.mono, fontWeight: '700', fontSize: 13.5 },
    propType: { color: c.textSubtle, fontFamily: Fonts.mono, fontSize: 12 },
    propDescription: { color: c.text, fontSize: 14, lineHeight: 20 },

    pager: { flexDirection: 'row', gap: Spacing.md },
    pagerItem: {
      flex: 1,
      padding: Spacing.md,
      borderRadius: Radius.md,
      borderWidth: 1,
      borderColor: c.border,
      backgroundColor: c.surface,
      gap: 2,
    },
    pagerItemNext: { alignItems: 'flex-end' },
    pagerSpacer: { flex: 1 },
    pagerLabel: { color: c.textSubtle, fontSize: 12 },
    pagerRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
    pagerName: { color: c.text, fontWeight: '700', fontSize: 15, flexShrink: 1 },
    footer: { textAlign: 'center', fontSize: 12 },

    notFound: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md, backgroundColor: c.background },
    title: { color: c.text, fontSize: 20, fontWeight: '700' },
    link: { color: c.primary, fontWeight: '700' },
  });
