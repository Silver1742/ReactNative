import type { CatalogEntry } from './types';

const docs = (slug: string) => `https://reactnative.dev/docs/${slug}`;
const ALL: CatalogEntry['platforms'] = ['ios', 'android', 'web'];

/**
 * Los componentes del core de React Native (paquete `react-native`).
 * Cada uno se traduce al widget nativo de la plataforma: <View> es un UIView en iOS,
 * un android.view.View en Android y un <div> en web (react-native-web).
 */
export const COMPONENTS: CatalogEntry[] = [
  // ───────────────────────────── Básicos ─────────────────────────────
  {
    id: 'view',
    name: 'View',
    kind: 'componente',
    category: 'basicos',
    summary: 'El bloque de construcción fundamental: un contenedor con layout Flexbox.',
    purpose:
      'Agrupa y posiciona otros componentes. Es el equivalente al <div> de la web: todo layout de una app (filas, columnas, tarjetas, separadores) se arma anidando Views con estilos.',
    useCases: ['Tarjetas y contenedores con fondo, borde o sombra', 'Filas y columnas con Flexbox', 'Separadores y espaciadores'],
    props: [
      { name: 'style', type: 'ViewStyle', description: 'Layout (flex, padding, margin), fondo, bordes, sombras y transformaciones.' },
      { name: 'onLayout', type: '(e) => void', description: 'Se dispara cuando cambia el tamaño o la posición calculados.' },
      { name: 'pointerEvents', type: "'auto' | 'none' | 'box-none' | 'box-only'", description: 'Controla si la vista (o sus hijos) reciben toques.' },
      { name: 'accessibilityRole', type: 'string', description: 'Rol que anuncian los lectores de pantalla.' },
    ],
    platforms: ALL,
    snippet: `<View style={{ flexDirection: 'row', gap: 8, padding: 16 }}>
  <View style={{ flex: 1, height: 40, backgroundColor: '#c8102e' }} />
  <View style={{ flex: 2, height: 40, backgroundColor: '#111' }} />
</View>`,
    docsUrl: docs('view'),
  },
  {
    id: 'text',
    name: 'Text',
    kind: 'componente',
    category: 'basicos',
    summary: 'Muestra texto. Es el único componente donde puede ir texto suelto.',
    purpose:
      'Todo string visible tiene que estar dentro de un <Text> (a diferencia de la web, un texto directo dentro de un View rompe). Soporta anidado para mezclar estilos, toques y truncado.',
    useCases: ['Títulos, párrafos y etiquetas', 'Texto con partes en negrita o con link', 'Truncar con "…" en listas'],
    props: [
      { name: 'numberOfLines', type: 'number', description: 'Corta el texto con "…" después de N líneas.' },
      { name: 'selectable', type: 'boolean', description: 'Permite seleccionar y copiar el texto.' },
      { name: 'onPress', type: '() => void', description: 'Hace el texto tocable (útil para links).' },
      { name: 'adjustsFontSizeToFit', type: 'boolean', description: 'Achica la fuente para que entre en el espacio.' },
    ],
    platforms: ALL,
    snippet: `<Text numberOfLines={2}>
  Texto normal y <Text style={{ fontWeight: 'bold' }}>negrita anidada</Text>
</Text>`,
    docsUrl: docs('text'),
  },
  {
    id: 'image',
    name: 'Image',
    kind: 'componente',
    category: 'basicos',
    summary: 'Muestra imágenes locales (require) o remotas (URI).',
    purpose:
      'Renderiza fotos, avatares, logos e íconos rasterizados. Las imágenes remotas necesitan un tamaño explícito porque no se conoce hasta que se descargan.',
    useCases: ['Avatares y fotos de perfil', 'Imágenes de productos', 'Logos e ilustraciones'],
    props: [
      { name: 'source', type: '{ uri } | require()', description: 'Origen de la imagen: URL remota o archivo del proyecto.' },
      { name: 'resizeMode', type: "'cover' | 'contain' | 'stretch' | 'center'", description: 'Cómo se ajusta la imagen a su caja.' },
      { name: 'onLoad / onError', type: '() => void', description: 'Eventos de carga correcta o fallida.' },
      { name: 'blurRadius', type: 'number', description: 'Aplica un desenfoque.' },
    ],
    platforms: ALL,
    note: 'En proyectos Expo se suele preferir expo-image (caché, transiciones, placeholders), pero <Image> es el componente core.',
    snippet: `<Image
  source={{ uri: 'https://picsum.photos/200' }}
  style={{ width: 120, height: 120, borderRadius: 60 }}
  resizeMode="cover"
/>`,
    docsUrl: docs('image'),
  },
  {
    id: 'imagebackground',
    name: 'ImageBackground',
    kind: 'componente',
    category: 'basicos',
    summary: 'Una imagen que se comporta como fondo y acepta hijos.',
    purpose:
      'En React Native no existe background-image en CSS clásico, así que para poner texto o botones encima de una foto se usa ImageBackground.',
    useCases: ['Portadas y banners con texto encima', 'Pantallas de bienvenida', 'Tarjetas con foto de fondo'],
    props: [
      { name: 'source', type: '{ uri } | require()', description: 'Imagen de fondo.' },
      { name: 'imageStyle', type: 'ImageStyle', description: 'Estilos aplicados solo a la imagen (por ej. borderRadius).' },
      { name: 'resizeMode', type: 'string', description: 'Igual que en Image.' },
    ],
    platforms: ALL,
    snippet: `<ImageBackground source={{ uri }} style={{ height: 160 }} imageStyle={{ borderRadius: 16 }}>
  <Text style={{ color: '#fff' }}>Texto sobre la imagen</Text>
</ImageBackground>`,
    docsUrl: docs('imagebackground'),
  },
  {
    id: 'textinput',
    name: 'TextInput',
    kind: 'componente',
    category: 'basicos',
    summary: 'Campo para que el usuario escriba con el teclado.',
    purpose:
      'Es el input de formularios: login, búsquedas, chats. Es "controlado" igual que en React web: el valor vive en un useState y se actualiza con onChangeText.',
    useCases: ['Formularios de login y registro', 'Barras de búsqueda', 'Cajas de mensajes multilínea'],
    props: [
      { name: 'value / onChangeText', type: 'string / (text) => void', description: 'Valor controlado y callback al escribir.' },
      { name: 'placeholder', type: 'string', description: 'Texto de ayuda cuando está vacío.' },
      { name: 'keyboardType', type: "'default' | 'email-address' | 'numeric' | …", description: 'Qué teclado mostrar.' },
      { name: 'secureTextEntry', type: 'boolean', description: 'Oculta el texto (contraseñas).' },
      { name: 'multiline', type: 'boolean', description: 'Permite varias líneas.' },
      { name: 'onSubmitEditing', type: '() => void', description: 'Se dispara al tocar "Enter"/"Listo".' },
    ],
    platforms: ALL,
    snippet: `const [email, setEmail] = useState('');

<TextInput
  value={email}
  onChangeText={setEmail}
  placeholder="tu@email.com"
  keyboardType="email-address"
  autoCapitalize="none"
/>`,
    docsUrl: docs('textinput'),
  },
  {
    id: 'scrollview',
    name: 'ScrollView',
    kind: 'componente',
    category: 'basicos',
    summary: 'Contenedor con scroll vertical u horizontal.',
    purpose:
      'En nativo una pantalla NO scrollea sola: si el contenido es más alto que la pantalla, hay que envolverlo en un ScrollView. Renderiza todos sus hijos de una vez, así que es para contenido acotado.',
    useCases: ['Pantallas de detalle o formularios largos', 'Carruseles horizontales', 'Paginado tipo onboarding (pagingEnabled)'],
    props: [
      { name: 'horizontal', type: 'boolean', description: 'Scroll horizontal en lugar de vertical.' },
      { name: 'contentContainerStyle', type: 'ViewStyle', description: 'Estilos del contenido interno (padding, gap).' },
      { name: 'pagingEnabled', type: 'boolean', description: 'Se detiene en múltiplos del ancho (páginas).' },
      { name: 'refreshControl', type: '<RefreshControl />', description: 'Agrega "tirar para refrescar".' },
      { name: 'keyboardShouldPersistTaps', type: "'never' | 'handled' | 'always'", description: 'Qué pasa con los toques cuando el teclado está abierto.' },
    ],
    platforms: ALL,
    note: 'Para listas largas o de tamaño desconocido usá FlatList: ScrollView monta todos los ítems a la vez.',
    snippet: `<ScrollView horizontal showsHorizontalScrollIndicator={false}>
  {items.map((item) => <Card key={item.id} {...item} />)}
</ScrollView>`,
    docsUrl: docs('scrollview'),
  },

  // ─────────────────────────── Interfaz de usuario ───────────────────────────
  {
    id: 'button',
    name: 'Button',
    kind: 'componente',
    category: 'interfaz',
    summary: 'Botón nativo básico de la plataforma.',
    purpose:
      'Botón listo para usar con el aspecto nativo de cada sistema. Admite muy poca personalización (solo color y título), por eso en apps con diseño propio se arma el botón con Pressable.',
    useCases: ['Prototipos rápidos', 'Pantallas internas o de debug', 'Cuando se quiere el look 100% nativo'],
    props: [
      { name: 'title', type: 'string', description: 'Texto del botón (obligatorio).' },
      { name: 'onPress', type: '() => void', description: 'Acción al tocarlo.' },
      { name: 'color', type: 'string', description: 'Color del texto (iOS) o del fondo (Android).' },
      { name: 'disabled', type: 'boolean', description: 'Deshabilita el botón.' },
    ],
    platforms: ALL,
    snippet: `<Button title="Guardar" color="#c8102e" onPress={guardar} />`,
    docsUrl: docs('button'),
  },
  {
    id: 'switch',
    name: 'Switch',
    kind: 'componente',
    category: 'interfaz',
    summary: 'Interruptor booleano de encendido/apagado.',
    purpose: 'Para opciones que se activan o desactivan al instante, como en una pantalla de ajustes. Es controlado: value + onValueChange.',
    useCases: ['Pantallas de configuración', 'Activar notificaciones', 'Modo oscuro'],
    props: [
      { name: 'value', type: 'boolean', description: 'Estado actual.' },
      { name: 'onValueChange', type: '(value) => void', description: 'Callback con el nuevo valor.' },
      { name: 'trackColor', type: '{ false, true }', description: 'Color del riel en cada estado.' },
      { name: 'thumbColor', type: 'string', description: 'Color de la perilla.' },
    ],
    platforms: ALL,
    snippet: `const [activo, setActivo] = useState(false);

<Switch value={activo} onValueChange={setActivo} trackColor={{ true: '#c8102e' }} />`,
    docsUrl: docs('switch'),
  },

  // ─────────────────────────── Listas ───────────────────────────
  {
    id: 'flatlist',
    name: 'FlatList',
    kind: 'componente',
    category: 'listas',
    summary: 'Lista performante que solo renderiza lo visible (virtualizada).',
    purpose:
      'El componente estándar para listas largas o que vienen de una API: monta solo los ítems que se ven y recicla memoria al scrollear. Trae pull-to-refresh, scroll infinito, columnas y separadores.',
    useCases: ['Feeds, chats y listados de productos', 'Scroll infinito con onEndReached', 'Grillas con numColumns'],
    props: [
      { name: 'data', type: 'T[]', description: 'Array de elementos.' },
      { name: 'renderItem', type: '({ item, index }) => Element', description: 'Cómo se dibuja cada ítem.' },
      { name: 'keyExtractor', type: '(item) => string', description: 'Key única por ítem.' },
      { name: 'ItemSeparatorComponent', type: 'Component', description: 'Separador entre ítems.' },
      { name: 'ListEmptyComponent', type: 'Element', description: 'Qué mostrar si no hay datos.' },
      { name: 'onEndReached', type: '() => void', description: 'Se dispara al llegar al final (paginación).' },
      { name: 'numColumns', type: 'number', description: 'Muestra los ítems en grilla.' },
    ],
    platforms: ALL,
    snippet: `<FlatList
  data={tareas}
  keyExtractor={(t) => String(t.id)}
  renderItem={({ item }) => <Text>{item.titulo}</Text>}
  ListEmptyComponent={<Text>Sin tareas</Text>}
/>`,
    docsUrl: docs('flatlist'),
  },
  {
    id: 'sectionlist',
    name: 'SectionList',
    kind: 'componente',
    category: 'listas',
    summary: 'Lista virtualizada agrupada en secciones con encabezado.',
    purpose:
      'Como FlatList, pero los datos vienen agrupados (contactos por letra, movimientos por fecha). Los encabezados pueden quedar fijos arriba mientras se scrollea. La pantalla principal de esta app es una SectionList.',
    useCases: ['Agenda de contactos A-Z', 'Movimientos agrupados por día', 'Menús por categoría'],
    props: [
      { name: 'sections', type: '{ title, data: T[] }[]', description: 'Grupos de datos.' },
      { name: 'renderItem', type: '({ item }) => Element', description: 'Cómo se dibuja cada ítem.' },
      { name: 'renderSectionHeader', type: '({ section }) => Element', description: 'Encabezado de cada grupo.' },
      { name: 'stickySectionHeadersEnabled', type: 'boolean', description: 'Encabezados fijos al scrollear.' },
    ],
    platforms: ALL,
    snippet: `<SectionList
  sections={[{ title: 'A', data: ['Ana', 'Andrés'] }, { title: 'B', data: ['Beto'] }]}
  keyExtractor={(item) => item}
  renderItem={({ item }) => <Text>{item}</Text>}
  renderSectionHeader={({ section }) => <Text>{section.title}</Text>}
/>`,
    docsUrl: docs('sectionlist'),
  },
  {
    id: 'virtualizedlist',
    name: 'VirtualizedList',
    kind: 'componente',
    category: 'listas',
    summary: 'La base sobre la que están hechas FlatList y SectionList.',
    purpose:
      'Se usa cuando los datos NO son un array (por ejemplo un Map, un objeto o un generador): uno le dice cuántos ítems hay (getItemCount) y cómo obtener cada uno (getItem).',
    useCases: ['Datos inmutables (Immutable.js) o estructuras propias', 'Listas "infinitas" calculadas', 'Casos que FlatList no cubre'],
    props: [
      { name: 'getItemCount', type: '(data) => number', description: 'Cuántos ítems hay.' },
      { name: 'getItem', type: '(data, index) => T', description: 'Cómo obtener el ítem en una posición.' },
      { name: 'renderItem', type: '({ item }) => Element', description: 'Cómo se dibuja cada ítem.' },
      { name: 'windowSize', type: 'number', description: 'Cuántas "pantallas" se mantienen montadas.' },
    ],
    platforms: ALL,
    snippet: `<VirtualizedList
  getItemCount={() => 1000}
  getItem={(_, index) => ({ id: index, label: \`Fila \${index}\` })}
  keyExtractor={(item) => String(item.id)}
  renderItem={({ item }) => <Text>{item.label}</Text>}
/>`,
    docsUrl: docs('virtualizedlist'),
  },

  // ─────────────────────────── Táctiles ───────────────────────────
  {
    id: 'pressable',
    name: 'Pressable',
    kind: 'componente',
    category: 'tactiles',
    summary: 'Detecta toques con estados (presionado, mantener, hover). Es la API recomendada.',
    purpose:
      'Es la forma moderna de hacer cualquier cosa tocable: botones propios, tarjetas, ítems de lista. Su style y children pueden ser funciones que reciben { pressed } para cambiar el diseño mientras se toca.',
    useCases: ['Botones con diseño propio', 'Tarjetas e ítems de lista tocables', 'Mantener presionado (onLongPress)'],
    props: [
      { name: 'onPress / onLongPress', type: '() => void', description: 'Toque corto y toque largo.' },
      { name: 'style', type: '({ pressed }) => Style', description: 'Estilo que depende de si está presionado.' },
      { name: 'hitSlop', type: 'number | Insets', description: 'Agranda el área tocable sin cambiar el diseño.' },
      { name: 'android_ripple', type: '{ color, borderless }', description: 'Efecto ripple de Material en Android.' },
      { name: 'disabled', type: 'boolean', description: 'Deshabilita los toques.' },
    ],
    platforms: ALL,
    snippet: `<Pressable
  onPress={guardar}
  style={({ pressed }) => [styles.boton, pressed && { opacity: 0.7 }]}>
  <Text>Guardar</Text>
</Pressable>`,
    docsUrl: docs('pressable'),
  },
  {
    id: 'touchableopacity',
    name: 'TouchableOpacity',
    kind: 'componente',
    category: 'tactiles',
    summary: 'Al tocarlo baja la opacidad de su contenido.',
    purpose: 'API clásica (anterior a Pressable) para botones con feedback de transparencia. Se sigue viendo muchísimo en código y tutoriales.',
    useCases: ['Botones e íconos tocables simples', 'Código legado'],
    props: [
      { name: 'onPress', type: '() => void', description: 'Acción al tocarlo.' },
      { name: 'activeOpacity', type: 'number', description: 'Opacidad mientras está presionado (por defecto 0.2).' },
    ],
    platforms: ALL,
    note: 'La documentación oficial recomienda Pressable para código nuevo.',
    snippet: `<TouchableOpacity activeOpacity={0.6} onPress={abrir}>
  <Text>Abrir</Text>
</TouchableOpacity>`,
    docsUrl: docs('touchableopacity'),
  },
  {
    id: 'touchablehighlight',
    name: 'TouchableHighlight',
    kind: 'componente',
    category: 'tactiles',
    summary: 'Al tocarlo muestra un color de fondo por debajo.',
    purpose: 'Feedback de "resaltado", típico de filas de listas en iOS. Acepta un único hijo.',
    useCases: ['Filas de listas y menús', 'Código legado'],
    props: [
      { name: 'onPress', type: '() => void', description: 'Acción al tocarlo.' },
      { name: 'underlayColor', type: 'string', description: 'Color que aparece debajo al presionar.' },
    ],
    platforms: ALL,
    note: 'Recomendado reemplazar por Pressable en código nuevo.',
    snippet: `<TouchableHighlight underlayColor="#fde8eb" onPress={abrir}>
  <View><Text>Fila</Text></View>
</TouchableHighlight>`,
    docsUrl: docs('touchablehighlight'),
  },
  {
    id: 'touchablewithoutfeedback',
    name: 'TouchableWithoutFeedback',
    kind: 'componente',
    category: 'tactiles',
    summary: 'Detecta el toque sin ningún efecto visual.',
    purpose: 'Para zonas tocables "invisibles", como cerrar el teclado al tocar fuera de un input o cerrar un menú tocando el fondo.',
    useCases: ['Cerrar el teclado tocando afuera (Keyboard.dismiss)', 'Fondos de modales/menús'],
    props: [{ name: 'onPress', type: '() => void', description: 'Acción al tocarlo.' }],
    platforms: ALL,
    note: 'Usar con moderación: sin feedback visual el usuario no sabe que algo es tocable.',
    snippet: `<TouchableWithoutFeedback onPress={Keyboard.dismiss}>
  <View style={{ flex: 1 }}>{/* formulario */}</View>
</TouchableWithoutFeedback>`,
    docsUrl: docs('touchablewithoutfeedback'),
  },

  // ─────────────────────────── Feedback ───────────────────────────
  {
    id: 'activityindicator',
    name: 'ActivityIndicator',
    kind: 'componente',
    category: 'feedback',
    summary: 'El spinner de carga nativo.',
    purpose: 'Indica que algo está cargando (un fetch, un guardado). Usa el spinner propio de cada sistema operativo.',
    useCases: ['Mientras se espera una API', 'Dentro de un botón mientras se envía un formulario', 'Pantallas de carga'],
    props: [
      { name: 'animating', type: 'boolean', description: 'Muestra u oculta el spinner.' },
      { name: 'size', type: "'small' | 'large' | number", description: 'Tamaño (number solo en Android).' },
      { name: 'color', type: 'string', description: 'Color del spinner.' },
    ],
    platforms: ALL,
    snippet: `{cargando ? <ActivityIndicator size="large" color="#c8102e" /> : <Lista />}`,
    docsUrl: docs('activityindicator'),
  },
  {
    id: 'modal',
    name: 'Modal',
    kind: 'componente',
    category: 'feedback',
    summary: 'Presenta contenido por encima de toda la app.',
    purpose: 'Ventanas emergentes: confirmaciones, formularios rápidos, hojas inferiores. Se controla con la prop visible desde un estado.',
    useCases: ['Confirmar acciones ("¿Eliminar?")', 'Formularios rápidos', 'Hojas inferiores (bottom sheets)'],
    props: [
      { name: 'visible', type: 'boolean', description: 'Si el modal se ve.' },
      { name: 'animationType', type: "'none' | 'slide' | 'fade'", description: 'Animación de entrada.' },
      { name: 'transparent', type: 'boolean', description: 'Fondo transparente para dibujar un overlay propio.' },
      { name: 'onRequestClose', type: '() => void', description: 'Botón "atrás" de Android (obligatorio allí).' },
    ],
    platforms: ALL,
    snippet: `<Modal visible={abierto} transparent animationType="fade" onRequestClose={() => setAbierto(false)}>
  <View style={styles.overlay}>{/* contenido */}</View>
</Modal>`,
    docsUrl: docs('modal'),
  },
  {
    id: 'refreshcontrol',
    name: 'RefreshControl',
    kind: 'componente',
    category: 'feedback',
    summary: '"Tirar para refrescar" en ScrollView y listas.',
    purpose: 'Se pasa a la prop refreshControl de un ScrollView/FlatList para que el usuario recargue los datos arrastrando hacia abajo.',
    useCases: ['Recargar un feed o una bandeja de entrada', 'Volver a pedir datos a la API'],
    props: [
      { name: 'refreshing', type: 'boolean', description: 'Si se está refrescando (muestra el spinner).' },
      { name: 'onRefresh', type: '() => void', description: 'Se dispara al tirar hacia abajo.' },
      { name: 'colors / tintColor', type: 'string[] / string', description: 'Color del indicador (Android / iOS).' },
    ],
    platforms: ['ios', 'android'],
    note: 'En web no hay gesto de "tirar para refrescar": el componente no hace nada.',
    snippet: `<FlatList
  data={data}
  renderItem={renderItem}
  refreshControl={<RefreshControl refreshing={cargando} onRefresh={recargar} />}
/>`,
    docsUrl: docs('refreshcontrol'),
  },
  {
    id: 'statusbar',
    name: 'StatusBar',
    kind: 'componente',
    category: 'feedback',
    summary: 'Controla la barra de estado del sistema (hora, batería, señal).',
    purpose: 'Permite cambiar el color de los íconos (claros/oscuros), ocultarla o cambiar su fondo en Android, según la pantalla.',
    useCases: ['Íconos claros sobre un header oscuro', 'Ocultar la barra en pantallas a pantalla completa'],
    props: [
      { name: 'barStyle', type: "'default' | 'light-content' | 'dark-content'", description: 'Color de los íconos.' },
      { name: 'hidden', type: 'boolean', description: 'Oculta la barra.' },
      { name: 'backgroundColor', type: 'string', description: 'Color de fondo (solo Android).' },
    ],
    platforms: ['ios', 'android'],
    note: 'En Expo es más común expo-status-bar, que elige el estilo automáticamente según el tema.',
    snippet: `<StatusBar barStyle="light-content" />`,
    docsUrl: docs('statusbar'),
  },

  // ─────────────────────────── Contenedores especiales ───────────────────────────
  {
    id: 'keyboardavoidingview',
    name: 'KeyboardAvoidingView',
    kind: 'componente',
    category: 'contenedores',
    summary: 'Se corre o achica para que el teclado no tape los inputs.',
    purpose: 'Cuando aparece el teclado virtual puede tapar el campo que se está escribiendo; este contenedor ajusta su padding o altura automáticamente.',
    useCases: ['Formularios de login', 'Pantallas de chat con la caja de texto abajo'],
    props: [
      { name: 'behavior', type: "'padding' | 'height' | 'position'", description: "Cómo reacciona. Suele usarse 'padding' en iOS y 'height' en Android." },
      { name: 'keyboardVerticalOffset', type: 'number', description: 'Compensa headers u otros elementos fijos.' },
    ],
    platforms: ['ios', 'android'],
    snippet: `<KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
  <TextInput placeholder="Mensaje" />
</KeyboardAvoidingView>`,
    docsUrl: docs('keyboardavoidingview'),
  },
  {
    id: 'safeareaview',
    name: 'SafeAreaView',
    kind: 'componente',
    category: 'contenedores',
    summary: 'Evita el notch, la isla dinámica y las barras del sistema.',
    purpose: 'Agrega el padding necesario para que el contenido no quede debajo del notch o de la barra de gestos.',
    useCases: ['Raíz de cada pantalla sin header de navegación'],
    props: [{ name: 'style', type: 'ViewStyle', description: 'Igual que View.' }],
    platforms: ['ios'],
    deprecated: true,
    note: 'El de react-native está deprecado (solo funcionaba en iOS). Se usa SafeAreaView de react-native-safe-area-context, que ya viene en Expo y funciona en todas las plataformas. Esta app lo usa así.',
    snippet: `import { SafeAreaView } from 'react-native-safe-area-context';

<SafeAreaView style={{ flex: 1 }} edges={['top']}>
  {/* pantalla */}
</SafeAreaView>`,
    docsUrl: docs('safeareaview'),
  },

  // ─────────────────────────── Solo Android ───────────────────────────
  {
    id: 'drawerlayoutandroid',
    name: 'DrawerLayoutAndroid',
    kind: 'componente',
    category: 'android',
    summary: 'Menú lateral deslizable nativo de Android.',
    purpose: 'Envuelve la pantalla y agrega un panel que se abre deslizando desde el borde o con openDrawer(). Es el "navigation drawer" de Material Design.',
    useCases: ['Menú de navegación lateral en apps Android'],
    props: [
      { name: 'renderNavigationView', type: '() => Element', description: 'Contenido del panel.' },
      { name: 'drawerPosition', type: "'left' | 'right'", description: 'De qué lado sale.' },
      { name: 'drawerWidth', type: 'number', description: 'Ancho del panel.' },
    ],
    platforms: ['android'],
    note: 'Para algo multiplataforma se usa el Drawer de expo-router / React Navigation.',
    snippet: `<DrawerLayoutAndroid ref={drawer} drawerWidth={280} renderNavigationView={() => <Menu />}>
  <Button title="Abrir menú" onPress={() => drawer.current?.openDrawer()} />
</DrawerLayoutAndroid>`,
    docsUrl: docs('drawerlayoutandroid'),
  },
  {
    id: 'touchablenativefeedback',
    name: 'TouchableNativeFeedback',
    kind: 'componente',
    category: 'android',
    summary: 'Toque con el efecto "ripple" (onda) de Android.',
    purpose: 'Usa el drawable nativo de Android para mostrar la onda de Material Design al tocar.',
    useCases: ['Botones con feedback nativo en Android'],
    props: [
      { name: 'background', type: 'TouchableNativeFeedback.Ripple(color, borderless)', description: 'Tipo de efecto.' },
      { name: 'useForeground', type: 'boolean', description: 'Dibuja la onda por encima del contenido.' },
    ],
    platforms: ['android'],
    note: 'Pressable con android_ripple logra lo mismo y además funciona en iOS y web.',
    snippet: `<TouchableNativeFeedback background={TouchableNativeFeedback.Ripple('#c8102e', false)}>
  <View style={styles.boton}><Text>Ripple</Text></View>
</TouchableNativeFeedback>`,
    docsUrl: docs('touchablenativefeedback'),
  },

  // ─────────────────────────── Solo iOS ───────────────────────────
  {
    id: 'inputaccessoryview',
    name: 'InputAccessoryView',
    kind: 'componente',
    category: 'ios',
    summary: 'Barra personalizada pegada arriba del teclado de iOS.',
    purpose: 'Agrega controles (botón "Listo", atajos, formato) justo encima del teclado cuando un TextInput está enfocado.',
    useCases: ['Botón "Listo" en teclados numéricos', 'Barras de formato en editores'],
    props: [
      { name: 'nativeID', type: 'string', description: 'Se vincula con inputAccessoryViewID del TextInput.' },
      { name: 'backgroundColor', type: 'string', description: 'Color de fondo de la barra.' },
    ],
    platforms: ['ios'],
    snippet: `<TextInput inputAccessoryViewID="barra" keyboardType="numeric" />
<InputAccessoryView nativeID="barra">
  <Button title="Listo" onPress={Keyboard.dismiss} />
</InputAccessoryView>`,
    docsUrl: docs('inputaccessoryview'),
  },
];
