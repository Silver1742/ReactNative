import type { CatalogEntry } from './types';

const docs = (slug: string) => `https://reactnative.dev/docs/${slug}`;
const ALL: CatalogEntry['platforms'] = ['ios', 'android', 'web'];

/**
 * APIs del core: no dibujan nada por sí mismas, exponen funciones nativas
 * (alertas, vibración, dimensiones, animaciones…) a JavaScript.
 */
export const APIS: CatalogEntry[] = [
  {
    id: 'stylesheet',
    name: 'StyleSheet',
    kind: 'api',
    category: 'apis',
    summary: 'Define los estilos de los componentes.',
    purpose: 'StyleSheet.create agrupa estilos con nombre y tipado. Además trae utilidades como hairlineWidth (el borde más fino posible) y absoluteFill.',
    useCases: ['Todos los estilos de la app', 'Bordes de 1 píxel físico', 'Capas que cubren todo el padre'],
    props: [
      { name: 'create(styles)', type: 'function', description: 'Crea el objeto de estilos.' },
      { name: 'hairlineWidth', type: 'number', description: 'Ancho de la línea más fina de la pantalla.' },
      { name: 'absoluteFill', type: 'object', description: 'position absolute con top/left/right/bottom en 0.' },
      { name: 'compose / flatten', type: 'function', description: 'Combina o aplana estilos.' },
    ],
    platforms: ALL,
    snippet: `const styles = StyleSheet.create({
  tarjeta: { padding: 16, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth },
});`,
    docsUrl: docs('stylesheet'),
  },
  {
    id: 'alert',
    name: 'Alert',
    kind: 'api',
    category: 'apis',
    summary: 'Muestra el cuadro de diálogo nativo del sistema.',
    purpose: 'Para avisos y confirmaciones rápidas con hasta tres botones, sin diseñar un modal propio.',
    useCases: ['"¿Seguro que querés eliminar?"', 'Errores de red', 'Avisos breves'],
    props: [
      { name: 'Alert.alert(título, mensaje?, botones?)', type: 'function', description: 'Abre el diálogo.' },
      { name: "botones[].style", type: "'default' | 'cancel' | 'destructive'", description: 'Estilo de cada botón (destructive = rojo en iOS).' },
    ],
    platforms: ALL,
    note: 'En web se traduce a window.alert / window.confirm con funcionalidad limitada.',
    snippet: `Alert.alert('Eliminar tarea', '¿Seguro?', [
  { text: 'Cancelar', style: 'cancel' },
  { text: 'Eliminar', style: 'destructive', onPress: eliminar },
]);`,
    docsUrl: docs('alert'),
  },
  {
    id: 'animated',
    name: 'Animated',
    kind: 'api',
    category: 'apis',
    summary: 'Sistema de animaciones declarativas del core.',
    purpose: 'Anima valores (opacidad, posición, escala) con timing, spring o decay. Con useNativeDriver la animación corre en el hilo nativo y no se traba aunque JS esté ocupado.',
    useCases: ['Fade-in de contenido', 'Botones que "rebotan"', 'Animaciones ligadas al scroll'],
    props: [
      { name: 'Animated.Value', type: 'class', description: 'Valor numérico animable.' },
      { name: 'timing / spring / decay', type: 'function', description: 'Tipos de animación.' },
      { name: 'Animated.View / Text / Image', type: 'component', description: 'Versiones animables de los componentes.' },
      { name: 'useNativeDriver', type: 'boolean', description: 'Ejecuta la animación en el hilo nativo.' },
    ],
    platforms: ALL,
    note: 'Para animaciones complejas o gestos se usa react-native-reanimated (ya incluido en Expo).',
    snippet: `const escala = useRef(new Animated.Value(1)).current;

Animated.spring(escala, { toValue: 1.2, useNativeDriver: true }).start();

<Animated.View style={{ transform: [{ scale: escala }] }} />`,
    docsUrl: docs('animated'),
  },
  {
    id: 'dimensions',
    name: 'useWindowDimensions',
    kind: 'api',
    category: 'apis',
    summary: 'Ancho y alto de la ventana, actualizados en vivo.',
    purpose: 'Hook para diseño responsive: se re-renderiza al rotar el teléfono, al cambiar el tamaño de la ventana en web o en tablets con multiventana.',
    useCases: ['Layouts distintos para celular y tablet', 'Columnas según el ancho', 'Tamaños proporcionales'],
    props: [
      { name: 'width / height', type: 'number', description: 'Tamaño en puntos (dp).' },
      { name: 'scale', type: 'number', description: 'Densidad de píxeles.' },
      { name: 'fontScale', type: 'number', description: 'Escala de fuente elegida por el usuario.' },
    ],
    platforms: ALL,
    note: 'Existe también Dimensions.get("window"), pero no se actualiza solo: el hook es lo recomendado.',
    snippet: `const { width } = useWindowDimensions();
const columnas = width > 700 ? 3 : 1;`,
    docsUrl: docs('usewindowdimensions'),
  },
  {
    id: 'platform',
    name: 'Platform',
    kind: 'api',
    category: 'apis',
    summary: 'Detecta en qué plataforma corre la app.',
    purpose: 'Permite tener código o estilos distintos para iOS, Android y web desde un mismo archivo.',
    useCases: ['Estilos diferentes por plataforma', 'Usar componentes que solo existen en un sistema'],
    props: [
      { name: 'Platform.OS', type: "'ios' | 'android' | 'web' | …", description: 'Plataforma actual.' },
      { name: 'Platform.Version', type: 'number | string', description: 'Versión del sistema operativo.' },
      { name: 'Platform.select({ ios, android, default })', type: 'function', description: 'Elige un valor según la plataforma.' },
    ],
    platforms: ALL,
    snippet: `const sombra = Platform.select({
  ios: { shadowOpacity: 0.2 },
  android: { elevation: 4 },
  default: { boxShadow: '0 2px 8px rgba(0,0,0,.2)' },
});`,
    docsUrl: docs('platform'),
  },
  {
    id: 'appearance',
    name: 'useColorScheme',
    kind: 'api',
    category: 'apis',
    summary: 'Indica si el sistema está en modo claro u oscuro.',
    purpose: 'Base del modo oscuro: devuelve "light" o "dark" y se actualiza cuando el usuario cambia el tema del sistema. Esta app lo usa en su ThemeContext.',
    useCases: ['Modo oscuro automático', 'Elegir colores según el tema del sistema'],
    props: [
      { name: 'useColorScheme()', type: "'light' | 'dark' | null", description: 'Esquema actual del sistema.' },
      { name: 'Appearance.addChangeListener', type: 'function', description: 'Escuchar cambios fuera de un componente.' },
    ],
    platforms: ALL,
    snippet: `const esquema = useColorScheme();
const fondo = esquema === 'dark' ? '#0b0b0c' : '#ffffff';`,
    docsUrl: docs('usecolorscheme'),
  },
  {
    id: 'keyboard',
    name: 'Keyboard',
    kind: 'api',
    category: 'apis',
    summary: 'Controla y escucha el teclado virtual.',
    purpose: 'Permite cerrar el teclado por código y reaccionar cuando aparece o desaparece.',
    useCases: ['Cerrar el teclado al enviar un formulario', 'Ocultar elementos mientras se escribe'],
    props: [
      { name: 'Keyboard.dismiss()', type: 'function', description: 'Cierra el teclado.' },
      { name: "addListener('keyboardDidShow' | 'keyboardDidHide')", type: 'function', description: 'Eventos del teclado.' },
    ],
    platforms: ['ios', 'android'],
    snippet: `useEffect(() => {
  const sub = Keyboard.addListener('keyboardDidShow', () => setAbierto(true));
  return () => sub.remove();
}, []);`,
    docsUrl: docs('keyboard'),
  },
  {
    id: 'linking',
    name: 'Linking',
    kind: 'api',
    category: 'apis',
    summary: 'Abre URLs y otras apps (navegador, teléfono, mail, mapas).',
    purpose: 'Interactúa con links entrantes y salientes: abrir una web, llamar por teléfono (tel:), mandar un mail (mailto:) o recibir deep links.',
    useCases: ['Abrir la documentación en el navegador', 'Botón "Llamar" o "Enviar mail"', 'Deep links hacia la app'],
    props: [
      { name: 'openURL(url)', type: 'Promise', description: 'Abre la URL con la app correspondiente.' },
      { name: 'canOpenURL(url)', type: 'Promise<boolean>', description: 'Verifica si hay una app para esa URL.' },
      { name: 'getInitialURL()', type: 'Promise', description: 'Link con el que se abrió la app.' },
    ],
    platforms: ALL,
    snippet: `await Linking.openURL('https://docs.expo.dev');
await Linking.openURL('mailto:contacto@burgoscorp.com');`,
    docsUrl: docs('linking'),
  },
  {
    id: 'share',
    name: 'Share',
    kind: 'api',
    category: 'apis',
    summary: 'Abre la hoja nativa de "Compartir".',
    purpose: 'Permite compartir texto o links con otras apps (WhatsApp, mail, etc.) usando el diálogo del sistema.',
    useCases: ['Compartir un producto o publicación', 'Invitar amigos'],
    props: [
      { name: 'Share.share({ message, url, title })', type: 'Promise', description: 'Abre el diálogo y devuelve qué hizo el usuario.' },
    ],
    platforms: ALL,
    note: 'En web usa la Web Share API, que no está disponible en todos los navegadores de escritorio.',
    snippet: `await Share.share({ message: 'Mirá este catálogo de React Native' });`,
    docsUrl: docs('share'),
  },
  {
    id: 'vibration',
    name: 'Vibration',
    kind: 'api',
    category: 'apis',
    summary: 'Hace vibrar el dispositivo.',
    purpose: 'Feedback táctil simple: una vibración o un patrón (vibrar, pausar, vibrar…).',
    useCases: ['Confirmar una acción importante', 'Alertas o errores'],
    props: [
      { name: 'vibrate(patrón?, repetir?)', type: 'function', description: 'Vibra una vez o con un patrón en ms.' },
      { name: 'cancel()', type: 'function', description: 'Detiene la vibración.' },
    ],
    platforms: ['ios', 'android'],
    note: 'En Android requiere el permiso VIBRATE (Expo ya lo agrega). Para feedback fino se usa expo-haptics.',
    snippet: `Vibration.vibrate([0, 200, 100, 200]);`,
    docsUrl: docs('vibration'),
  },
  {
    id: 'pixelratio',
    name: 'PixelRatio',
    kind: 'api',
    category: 'apis',
    summary: 'Densidad de píxeles de la pantalla.',
    purpose: 'Sirve para pedir imágenes del tamaño justo y para redondear medidas a píxeles físicos.',
    useCases: ['Pedir imágenes @2x / @3x a un servidor', 'Medidas nítidas sin borrosidad'],
    props: [
      { name: 'get()', type: 'number', description: 'Densidad (2 = retina, 3 = super retina…).' },
      { name: 'getFontScale()', type: 'number', description: 'Escala de fuente del usuario.' },
      { name: 'getPixelSizeForLayoutSize(dp)', type: 'number', description: 'Convierte dp a píxeles físicos.' },
    ],
    platforms: ALL,
    snippet: `const tamaño = PixelRatio.getPixelSizeForLayoutSize(120);
const uri = \`https://picsum.photos/\${tamaño}\`;`,
    docsUrl: docs('pixelratio'),
  },
  {
    id: 'accessibilityinfo',
    name: 'AccessibilityInfo',
    kind: 'api',
    category: 'apis',
    summary: 'Consulta el estado de las opciones de accesibilidad.',
    purpose: 'Permite saber si hay un lector de pantalla activo o si el usuario pidió reducir el movimiento, para adaptar la app.',
    useCases: ['Desactivar animaciones si "reducir movimiento" está activo', 'Anunciar cambios al lector de pantalla'],
    props: [
      { name: 'isScreenReaderEnabled()', type: 'Promise<boolean>', description: 'TalkBack / VoiceOver activo.' },
      { name: 'isReduceMotionEnabled()', type: 'Promise<boolean>', description: 'Preferencia de reducir movimiento.' },
      { name: 'announceForAccessibility(texto)', type: 'function', description: 'Lee un mensaje en voz alta.' },
    ],
    platforms: ALL,
    snippet: `const reducir = await AccessibilityInfo.isReduceMotionEnabled();`,
    docsUrl: docs('accessibilityinfo'),
  },
  {
    id: 'backhandler',
    name: 'BackHandler',
    kind: 'api',
    category: 'apis',
    summary: 'Intercepta el botón/gesto "atrás" de Android.',
    purpose: 'Permite decidir qué pasa al ir hacia atrás: cerrar un modal, pedir confirmación antes de salir, etc.',
    useCases: ['"¿Salir sin guardar?"', 'Cerrar un panel antes de navegar atrás'],
    props: [
      { name: "addEventListener('hardwareBackPress', fn)", type: 'function', description: 'fn devuelve true para cancelar el comportamiento por defecto.' },
    ],
    platforms: ['android'],
    snippet: `useEffect(() => {
  const sub = BackHandler.addEventListener('hardwareBackPress', () => {
    confirmarSalida();
    return true;
  });
  return () => sub.remove();
}, []);`,
    docsUrl: docs('backhandler'),
  },
  {
    id: 'toastandroid',
    name: 'ToastAndroid',
    kind: 'api',
    category: 'apis',
    summary: 'Mensajito flotante nativo de Android ("toast").',
    purpose: 'Notificación breve que aparece abajo y desaparece sola, sin interrumpir al usuario.',
    useCases: ['"Guardado"', '"Copiado al portapapeles"'],
    props: [
      { name: 'show(mensaje, duración)', type: 'function', description: 'ToastAndroid.SHORT o ToastAndroid.LONG.' },
    ],
    platforms: ['android'],
    snippet: `ToastAndroid.show('Tarea guardada', ToastAndroid.SHORT);`,
    docsUrl: docs('toastandroid'),
  },
  {
    id: 'actionsheetios',
    name: 'ActionSheetIOS',
    kind: 'api',
    category: 'apis',
    summary: 'Hoja de acciones nativa de iOS.',
    purpose: 'Muestra un menú de opciones que sube desde abajo, con estilo de iOS (incluida la opción destructiva en rojo).',
    useCases: ['Menú "Editar / Compartir / Eliminar"', 'Elegir origen de una foto (cámara o galería)'],
    props: [
      { name: 'showActionSheetWithOptions(opciones, callback)', type: 'function', description: 'options, cancelButtonIndex, destructiveButtonIndex…' },
    ],
    platforms: ['ios'],
    snippet: `ActionSheetIOS.showActionSheetWithOptions(
  { options: ['Cancelar', 'Eliminar'], cancelButtonIndex: 0, destructiveButtonIndex: 1 },
  (indice) => indice === 1 && eliminar(),
);`,
    docsUrl: docs('actionsheetios'),
  },
];
