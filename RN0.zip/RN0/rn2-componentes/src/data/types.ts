export type Platform = 'ios' | 'android' | 'web';

export type CategoryId =
  | 'basicos'
  | 'interfaz'
  | 'listas'
  | 'tactiles'
  | 'feedback'
  | 'contenedores'
  | 'android'
  | 'ios'
  | 'apis';

export type Category = {
  id: CategoryId;
  title: string;
  description: string;
};

export type PropDoc = {
  name: string;
  type: string;
  description: string;
};

/** Ficha de un componente o API del core de React Native. */
export type CatalogEntry = {
  /** Identificador estable, también usado en la URL: /detalle/flatlist */
  id: string;
  name: string;
  kind: 'componente' | 'api';
  category: CategoryId;
  /** Una línea: qué es. */
  summary: string;
  /** Párrafo: para qué se usa en una app real. */
  purpose: string;
  useCases: string[];
  props: PropDoc[];
  platforms: Platform[];
  /** Aviso importante (deprecado, solo una plataforma, alternativa recomendada…). */
  note?: string;
  deprecated?: boolean;
  snippet: string;
  docsUrl: string;
};
