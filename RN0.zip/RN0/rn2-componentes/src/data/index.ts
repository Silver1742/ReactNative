import { APIS } from './apis';
import { COMPONENTS } from './components';
import type { CatalogEntry, Category, CategoryId, Platform } from './types';

export * from './types';
export { APIS, COMPONENTS };

export const CATEGORIES: Category[] = [
  { id: 'basicos', title: 'Básicos', description: 'Los bloques con los que se arma cualquier pantalla.' },
  { id: 'interfaz', title: 'Interfaz de usuario', description: 'Controles nativos listos para usar.' },
  { id: 'listas', title: 'Listas', description: 'Listas virtualizadas para muchos datos.' },
  { id: 'tactiles', title: 'Táctiles', description: 'Cómo detectar y dar feedback a los toques.' },
  { id: 'feedback', title: 'Feedback y superposiciones', description: 'Carga, modales y barra de estado.' },
  { id: 'contenedores', title: 'Contenedores especiales', description: 'Teclado y áreas seguras de la pantalla.' },
  { id: 'android', title: 'Solo Android', description: 'Componentes que existen únicamente en Android.' },
  { id: 'ios', title: 'Solo iOS', description: 'Componentes que existen únicamente en iOS.' },
  { id: 'apis', title: 'APIs', description: 'Funciones nativas expuestas a JavaScript.' },
];

export const PLATFORM_LABEL: Record<Platform, string> = {
  ios: 'iOS',
  android: 'Android',
  web: 'Web',
};

const ALL_ENTRIES = [...COMPONENTS, ...APIS];
const BY_ID = new Map(ALL_ENTRIES.map((entry) => [entry.id, entry]));

export function getEntry(id: string): CatalogEntry | undefined {
  return BY_ID.get(id);
}

export function getCategory(id: CategoryId): Category {
  // Las categorías son una lista cerrada tipada: si no está es un error de programación.
  return CATEGORIES.find((category) => category.id === id)!;
}

/** Anterior y siguiente dentro de la misma colección (componentes o APIs), para navegar desde el detalle. */
export function getNeighbors(entry: CatalogEntry): { previous?: CatalogEntry; next?: CatalogEntry } {
  const list = entry.kind === 'api' ? APIS : COMPONENTS;
  const index = list.findIndex((item) => item.id === entry.id);
  return { previous: list[index - 1], next: list[index + 1] };
}

/** Normaliza para buscar sin importar mayúsculas ni tildes ("animacion" encuentra "animación"). */
function normalize(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase();
}

export function matchesQuery(entry: CatalogEntry, query: string): boolean {
  const needle = normalize(query.trim());
  if (!needle) return true;
  return normalize(`${entry.name} ${entry.summary} ${entry.purpose}`).includes(needle);
}

export type CatalogSection = Category & { data: CatalogEntry[] };

/** Agrupa por categoría respetando el orden de CATEGORIES y descarta las vacías. */
export function groupByCategory(entries: CatalogEntry[]): CatalogSection[] {
  return CATEGORIES.map((category) => ({
    ...category,
    data: entries.filter((entry) => entry.category === category.id),
  })).filter((section) => section.data.length > 0);
}
