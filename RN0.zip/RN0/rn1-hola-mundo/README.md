# RN1 · Hola mundo con React Native + Expo

Primer proyecto en **React Native con Expo**: una pantalla limpia con un “¡Hola, mundo!” y un **segundo tab con estilos diferentes**, todo con la identidad de **BurgosCorp** (rojo, negro y gris) y modo claro/oscuro.

| Tab | Qué muestra |
|---|---|
| **Hola mundo** (`src/app/index.tsx`) | Pantalla limpia, sin header: logo, título, subtítulo y un chip que indica en qué plataforma corre (iOS / Android / Web). |
| **Estilos** (`src/app/estilos.tsx`) | Galería de estilos: header rojo, tab bar negra mientras está activa, degradado, tipografía, botones con estado *pressed*, bordes y sombras, Flexbox interactivo, transformaciones y la paleta del tema. |

## Stack

- **Expo SDK 57** + **React Native 0.86** + **React 19** (React Compiler activado)
- **TypeScript** en modo `strict`
- **Expo Router** (rutas por archivos) con **tabs** (`expo-router/js-tabs`)
- `react-native-svg` para el logo, `expo-symbols` para los íconos (SF Symbols en iOS, Material Symbols en Android/web)

## Cómo correrlo

```bash
npm install
npx expo start
```

Después:

- **Celular:** instalá **Expo Go** (Play Store / App Store) y escaneá el QR que aparece en la terminal.
- **Web:** apretá `w` en la terminal (o `npm run web`).
- **Emulador Android:** apretá `a` (necesita Android Studio).

### Si el celular no conecta

- El celu y la PC tienen que estar en la **misma red Wi-Fi**, marcada como **privada** en Windows, y Node.js tiene que estar **permitido** en el firewall para redes privadas.
- Si el router aísla a los dispositivos entre sí (pasa en muchos routers de fibra), usá el modo túnel. `@expo/ngrok` ya está instalado en el proyecto:

```bash
npx expo start --tunnel
```

- Si Expo Go muestra *"Failed to download remote update"* en la primera carga, tocá **recargar**: es un timeout mientras se arma la app por primera vez.

Verificar tipos: `npm run typecheck`.

## Estructura

```
src/
├── app/                 # Rutas (Expo Router): cada archivo es una pantalla
│   ├── _layout.tsx      # Providers + navegación por tabs
│   ├── index.tsx        # Tab 1 · Hola mundo
│   └── estilos.tsx      # Tab 2 · Galería de estilos
├── components/
│   ├── BrandLogo.tsx    # Escudo "BC" en SVG (mismo que la versión web)
│   ├── Icon.tsx         # Ícono multiplataforma
│   └── ThemeToggle.tsx  # Botón Sistema → Claro → Oscuro
└── theme/
    ├── tokens.ts        # Colores, espaciados, radios y fuentes
    ├── ThemeContext.tsx # Context del tema + useThemedStyles
    └── navigationTheme.ts
```

## Decisiones

- **Tema con Context:** `AppThemeProvider` combina la preferencia del usuario (sistema / claro / oscuro) con `useColorScheme()`; las pantallas crean sus estilos con `useThemedStyles(createStyles)`, que los memoriza por tema.
- **Sin CSS:** en React Native los estilos son objetos (`StyleSheet.create`), en camelCase y sin unidades; el layout es Flexbox en columna por defecto. La galería de estilos lo muestra en vivo.
- **Estilos por pantalla en la navegación:** el tab *Estilos* define su propio `headerStyle` y `tabBarStyle`, así la barra cambia de look solo mientras ese tab está activo.

Documentación: [docs.expo.dev](https://docs.expo.dev/)
