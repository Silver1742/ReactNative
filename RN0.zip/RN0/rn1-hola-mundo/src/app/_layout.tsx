import { ThemeProvider } from 'expo-router';
import { Tabs } from 'expo-router/js-tabs';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { Icon } from '@/components/Icon';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AppThemeProvider, buildNavigationTheme, useAppTheme } from '@/theme';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <AppThemeProvider>
        <ThemedTabs />
      </AppThemeProvider>
    </SafeAreaProvider>
  );
}

/**
 * Navegación por tabs (expo-router: cada archivo de src/app es una ruta).
 * Separado del layout para poder leer el tema que provee AppThemeProvider.
 */
function ThemedTabs() {
  const { scheme, colors } = useAppTheme();

  return (
    <ThemeProvider value={buildNavigationTheme(scheme, colors)}>
      <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textSubtle,
          tabBarLabelStyle: { fontWeight: '600' },
          tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        }}>
        {/* Tab 1: pantalla limpia, sin header. */}
        <Tabs.Screen
          name="index"
          options={{
            title: 'Hola mundo',
            headerShown: false,
            tabBarIcon: ({ color, size }) => (
              <Icon name={{ ios: 'hand.wave.fill', android: 'waving_hand', web: 'waving_hand' }} color={color} size={size} />
            ),
          }}
        />

        {/* Tab 2: estilos distintos — header rojo y tab bar negra mientras está activa. */}
        <Tabs.Screen
          name="estilos"
          options={{
            title: 'Estilos',
            headerTitle: 'Galería de estilos',
            headerStyle: { backgroundColor: colors.primary },
            headerTintColor: '#ffffff',
            headerTitleStyle: { fontWeight: '800', letterSpacing: 0.5 },
            headerShadowVisible: false,
            headerRight: () => <ThemeToggle tone="onColor" />,
            headerRightContainerStyle: { paddingRight: 16 },
            tabBarActiveTintColor: '#ffffff',
            tabBarInactiveTintColor: '#a1a1aa',
            tabBarActiveBackgroundColor: colors.primary,
            tabBarStyle: { backgroundColor: '#111111', borderTopColor: colors.primary, borderTopWidth: 2 },
            tabBarIcon: ({ color, size }) => (
              <Icon name={{ ios: 'paintpalette.fill', android: 'palette', web: 'palette' }} color={color} size={size} />
            ),
          }}
        />
      </Tabs>
    </ThemeProvider>
  );
}
