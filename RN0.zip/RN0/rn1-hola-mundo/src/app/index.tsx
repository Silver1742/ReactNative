import { Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { BrandLogo } from '@/components/BrandLogo';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Radius, Spacing, useThemedStyles, type ThemeColors } from '@/theme';

const PLATFORM_LABEL: Record<string, string> = {
  ios: 'iOS',
  android: 'Android',
  web: 'Web',
};

/** Tab 1 · Pantalla limpia con el "Hola mundo". */
export default function HolaMundoScreen() {
  const styles = useThemedStyles(createStyles);

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <View style={styles.toolbar}>
        <ThemeToggle />
      </View>

      <View style={styles.center}>
        <BrandLogo size={72} />
        <Text style={styles.title} accessibilityRole="header">
          ¡Hola, mundo!
        </Text>
        <Text style={styles.subtitle}>Mi primera app con React Native + Expo</Text>

        <View style={styles.chip}>
          <View style={styles.dot} />
          <Text style={styles.chipText}>Corriendo en {PLATFORM_LABEL[Platform.OS] ?? Platform.OS}</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    safeArea: {
      flex: 1,
      backgroundColor: c.background,
    },
    toolbar: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      paddingHorizontal: Spacing.lg,
      paddingTop: Spacing.sm,
    },
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: Spacing.xl,
      gap: Spacing.md,
    },
    title: {
      marginTop: Spacing.sm,
      fontSize: 40,
      fontWeight: '800',
      color: c.text,
      textAlign: 'center',
      letterSpacing: -0.5,
    },
    subtitle: {
      fontSize: 16,
      color: c.textMuted,
      textAlign: 'center',
    },
    chip: {
      marginTop: Spacing.lg,
      flexDirection: 'row',
      alignItems: 'center',
      gap: Spacing.sm,
      paddingHorizontal: Spacing.md,
      paddingVertical: Spacing.xs + 2,
      borderRadius: Radius.pill,
      backgroundColor: c.primarySoft,
    },
    dot: {
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: c.primary,
    },
    chipText: {
      fontSize: 13,
      fontWeight: '600',
      color: c.primaryText,
    },
  });
