import { useState, type PropsWithChildren } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View, type ViewStyle } from 'react-native';

import { Fonts, MaxContentWidth, Radius, Spacing, useAppTheme, useThemedStyles, type ThemeColors } from '@/theme';

type Justify = NonNullable<ViewStyle['justifyContent']>;
const JUSTIFY_OPTIONS: Justify[] = ['flex-start', 'center', 'space-between', 'space-evenly'];

/** Tab 2 · Muestrario de estilos: cada bloque usa una técnica distinta de StyleSheet. */
export default function EstilosScreen() {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();
  const [justify, setJustify] = useState<Justify>('space-between');
  const [likes, setLikes] = useState(0);

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
      <View style={styles.column}>
        {/* 1 · Hero con degradado (experimental_backgroundImage) y franja de acento. */}
        <View style={styles.hero}>
          <View style={styles.heroStripe} />
          <Text style={styles.heroKicker}>BURGOSCORP · REACT NATIVE</Text>
          <Text style={styles.heroTitle}>Mismo componente,{'\n'}otro estilo.</Text>
          <Text style={styles.heroBody}>
            En React Native no hay CSS: los estilos son objetos JavaScript con nombres en camelCase y unidades sin
            &quot;px&quot;, y el layout es Flexbox por defecto (en columna).
          </Text>
        </View>

        {/* 2 · Tipografía */}
        <Section title="Tipografía" hint="fontSize · fontWeight · fontStyle · letterSpacing">
          <Text style={[styles.text, styles.display]}>Display 32 / 800</Text>
          <Text style={[styles.text, styles.heading]}>Título 22 / 700</Text>
          <Text style={styles.text}>Cuerpo 16 / 400 — texto de lectura normal.</Text>
          <Text style={[styles.text, styles.italic]}>Cursiva para citas o aclaraciones.</Text>
          <Text style={[styles.text, styles.underline]}>Subrayado con color de acento</Text>
          <Text style={[styles.text, styles.overline]}>Overline en mayúsculas</Text>
          <Text style={[styles.text, styles.mono]}>const estilo = StyleSheet.create(&#123;…&#125;)</Text>
        </Section>

        {/* 3 · Botones con estado "pressed" */}
        <Section title="Botones" hint="Pressable + style como función de { pressed }">
          <View style={styles.wrapRow}>
            <StyledButton variant="solid" label={`Me gusta · ${likes}`} onPress={() => setLikes((n) => n + 1)} />
            <StyledButton variant="outline" label="Reiniciar" onPress={() => setLikes(0)} />
            <StyledButton variant="ghost" label="Ghost" onPress={() => {}} />
            <StyledButton variant="solid" label="Deshabilitado" disabled onPress={() => {}} />
          </View>
        </Section>

        {/* 4 · Bordes, radios y sombras */}
        <Section title="Bordes y sombras" hint="borderRadius · borderWidth · boxShadow">
          <View style={styles.wrapRow}>
            <View style={[styles.tile, styles.tileFlat]}>
              <Text style={styles.tileLabel}>Plano</Text>
            </View>
            <View style={[styles.tile, styles.tileBorder]}>
              <Text style={styles.tileLabel}>Borde</Text>
            </View>
            <View style={[styles.tile, styles.tileShadow]}>
              <Text style={styles.tileLabel}>Sombra</Text>
            </View>
            <View style={[styles.tile, styles.tileGlow]}>
              <Text style={[styles.tileLabel, { color: colors.primaryText }]}>Glow</Text>
            </View>
            <View style={[styles.tile, styles.tileCircle]}>
              <Text style={[styles.tileLabel, { color: '#ffffff' }]}>Círculo</Text>
            </View>
          </View>
        </Section>

        {/* 5 · Flexbox interactivo */}
        <Section title="Flexbox" hint="flexDirection: 'row' · justifyContent">
          <View style={styles.segmented}>
            {JUSTIFY_OPTIONS.map((option) => {
              const active = option === justify;
              return (
                <Pressable
                  key={option}
                  onPress={() => setJustify(option)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                  style={[styles.segment, active && styles.segmentActive]}>
                  <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{option}</Text>
                </Pressable>
              );
            })}
          </View>
          <View style={[styles.flexStage, { justifyContent: justify }]}>
            {['A', 'B', 'C'].map((letter, index) => (
              <View key={letter} style={[styles.flexBox, { opacity: 1 - index * 0.25 }]}>
                <Text style={styles.flexBoxText}>{letter}</Text>
              </View>
            ))}
          </View>
        </Section>

        {/* 6 · Transformaciones */}
        <Section title="Transformaciones" hint="transform: rotate · scale · skewX">
          <View style={styles.wrapRow}>
            <View style={[styles.transformBox, { transform: [{ rotate: '-8deg' }] }]}>
              <Text style={styles.transformText}>rotate</Text>
            </View>
            <View style={[styles.transformBox, { transform: [{ scale: 0.85 }] }]}>
              <Text style={styles.transformText}>scale</Text>
            </View>
            <View style={[styles.transformBox, { transform: [{ skewX: '-12deg' }] }]}>
              <Text style={styles.transformText}>skewX</Text>
            </View>
          </View>
        </Section>

        {/* 7 · Paleta */}
        <Section title="Paleta" hint="Tokens del tema activo (claro / oscuro)">
          <View style={styles.wrapRow}>
            {(['primary', 'inverse', 'text', 'textMuted', 'border', 'surfaceMuted'] as const).map((token) => (
              <View key={token} style={styles.swatch}>
                <View style={[styles.swatchColor, { backgroundColor: colors[token] }]} />
                <Text style={styles.swatchLabel}>{token}</Text>
                <Text style={styles.swatchValue}>{colors[token]}</Text>
              </View>
            ))}
          </View>
        </Section>
      </View>
    </ScrollView>
  );
}

function Section({ title, hint, children }: PropsWithChildren<{ title: string; hint: string }>) {
  const styles = useThemedStyles(createStyles);
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle} accessibilityRole="header">
        {title}
      </Text>
      <Text style={styles.sectionHint}>{hint}</Text>
      <View style={styles.sectionBody}>{children}</View>
    </View>
  );
}

type ButtonVariant = 'solid' | 'outline' | 'ghost';

function StyledButton({
  label,
  variant,
  disabled = false,
  onPress,
}: {
  label: string;
  variant: ButtonVariant;
  disabled?: boolean;
  onPress: () => void;
}) {
  const styles = useThemedStyles(createStyles);
  const { colors } = useAppTheme();

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      style={({ pressed }) => [
        styles.button,
        variant === 'solid' && { backgroundColor: pressed ? colors.primaryPressed : colors.primary },
        variant === 'outline' && [styles.buttonOutline, pressed && { backgroundColor: colors.primarySoft }],
        variant === 'ghost' && pressed && { backgroundColor: colors.surfaceMuted },
        pressed && styles.buttonPressed,
        disabled && styles.buttonDisabled,
      ]}>
      <Text style={[styles.buttonText, { color: variant === 'solid' ? colors.onPrimary : colors.primary }]}>
        {label}
      </Text>
    </Pressable>
  );
}

const createStyles = (c: ThemeColors) =>
  StyleSheet.create({
    scroll: { flex: 1, backgroundColor: c.background },
    content: { padding: Spacing.lg, paddingBottom: Spacing.xxxl, alignItems: 'center' },
    column: { width: '100%', maxWidth: MaxContentWidth, gap: Spacing.lg },

    hero: {
      overflow: 'hidden',
      borderRadius: Radius.xl,
      padding: Spacing.xl,
      paddingLeft: Spacing.xl + Spacing.sm,
      backgroundColor: '#111111',
      experimental_backgroundImage: 'linear-gradient(135deg, #2e2e33 0%, #050505 100%)',
      gap: Spacing.sm,
    },
    heroStripe: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 6, backgroundColor: '#e11d2e' },
    heroKicker: { color: '#ef3b4f', fontSize: 12, fontWeight: '800', letterSpacing: 2 },
    heroTitle: { color: '#ffffff', fontSize: 28, lineHeight: 34, fontWeight: '800' },
    heroBody: { color: '#d4d4d8', fontSize: 15, lineHeight: 22 },

    section: {
      backgroundColor: c.surface,
      borderRadius: Radius.lg,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: c.border,
      padding: Spacing.lg,
    },
    sectionTitle: { color: c.text, fontSize: 18, fontWeight: '700' },
    sectionHint: { color: c.textSubtle, fontSize: 12, marginTop: 2, fontFamily: Fonts.mono },
    sectionBody: { marginTop: Spacing.md, gap: Spacing.sm },

    text: { color: c.text, fontSize: 16 },
    display: { fontSize: 32, fontWeight: '800', letterSpacing: -0.5 },
    heading: { fontSize: 22, fontWeight: '700' },
    italic: { fontStyle: 'italic', color: c.textMuted },
    underline: { textDecorationLine: 'underline', textDecorationColor: c.primary, textDecorationStyle: 'solid' },
    overline: { fontSize: 12, fontWeight: '700', letterSpacing: 2, textTransform: 'uppercase', color: c.primary },
    mono: { fontFamily: Fonts.mono, fontSize: 13, color: c.textMuted, backgroundColor: c.surfaceMuted, padding: Spacing.sm, borderRadius: Radius.sm },

    wrapRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },

    button: {
      paddingHorizontal: Spacing.lg,
      paddingVertical: Spacing.md - 2,
      borderRadius: Radius.md,
      minWidth: 96,
      alignItems: 'center',
    },
    buttonOutline: { borderWidth: 1.5, borderColor: c.primary },
    buttonPressed: { transform: [{ scale: 0.97 }] },
    buttonDisabled: { opacity: 0.4 },
    buttonText: { fontWeight: '700', fontSize: 15 },

    tile: { width: 92, height: 72, alignItems: 'center', justifyContent: 'center', backgroundColor: c.surfaceMuted },
    tileFlat: { borderRadius: 0 },
    tileBorder: { borderRadius: Radius.md, borderWidth: 2, borderColor: c.text, borderStyle: 'dashed' },
    tileShadow: { borderRadius: Radius.lg, backgroundColor: c.surface, boxShadow: '0 6px 16px rgba(0, 0, 0, 0.18)' },
    tileGlow: { borderRadius: Radius.lg, backgroundColor: c.primarySoft, boxShadow: `0 0 18px ${c.primary}` },
    tileCircle: { width: 72, borderRadius: 36, backgroundColor: '#111111', borderWidth: 2, borderColor: c.primary },
    tileLabel: { color: c.text, fontSize: 12, fontWeight: '700' },

    segmented: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, backgroundColor: c.surfaceMuted, padding: Spacing.xs, borderRadius: Radius.md },
    segment: { paddingHorizontal: Spacing.sm + 2, paddingVertical: Spacing.xs + 2, borderRadius: Radius.sm },
    segmentActive: { backgroundColor: c.surface, boxShadow: '0 1px 3px rgba(0, 0, 0, 0.15)' },
    segmentText: { fontSize: 12, color: c.textMuted, fontFamily: Fonts.mono },
    segmentTextActive: { color: c.primary, fontWeight: '700' },
    flexStage: {
      flexDirection: 'row',
      gap: Spacing.sm,
      padding: Spacing.sm,
      borderRadius: Radius.md,
      borderWidth: 1,
      borderColor: c.border,
      borderStyle: 'dashed',
    },
    flexBox: { width: 48, height: 48, borderRadius: Radius.sm, backgroundColor: c.primary, alignItems: 'center', justifyContent: 'center' },
    flexBoxText: { color: c.onPrimary, fontWeight: '800', fontSize: 18 },

    transformBox: { width: 88, height: 56, borderRadius: Radius.md, backgroundColor: c.inverse, alignItems: 'center', justifyContent: 'center' },
    transformText: { color: c.onInverse, fontFamily: Fonts.mono, fontWeight: '700' },

    swatch: { width: 96, gap: 2 },
    swatchColor: { height: 44, borderRadius: Radius.md, borderWidth: StyleSheet.hairlineWidth, borderColor: c.border },
    swatchLabel: { color: c.text, fontSize: 12, fontWeight: '600', marginTop: Spacing.xs },
    swatchValue: { color: c.textSubtle, fontSize: 11, fontFamily: Fonts.mono },
  });
