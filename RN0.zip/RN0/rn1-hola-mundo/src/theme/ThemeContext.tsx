import { createContext, use, useMemo, useState, type PropsWithChildren } from 'react';
import { useColorScheme } from 'react-native';

import { Colors, type ColorScheme, type ThemeColors } from './tokens';

/** Preferencia del usuario: seguir al sistema o forzar un modo. */
export type ThemePreference = 'system' | ColorScheme;

type ThemeContextValue = {
  /** Esquema efectivo que se está pintando. */
  scheme: ColorScheme;
  colors: ThemeColors;
  preference: ThemePreference;
  setPreference: (preference: ThemePreference) => void;
  /** Rota sistema → claro → oscuro → sistema. */
  cyclePreference: () => void;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

const NEXT_PREFERENCE: Record<ThemePreference, ThemePreference> = {
  system: 'light',
  light: 'dark',
  dark: 'system',
};

export function AppThemeProvider({ children }: PropsWithChildren) {
  const systemScheme = useColorScheme();
  const [preference, setPreference] = useState<ThemePreference>('system');

  const scheme: ColorScheme =
    preference === 'system' ? (systemScheme === 'dark' ? 'dark' : 'light') : preference;

  const value = useMemo<ThemeContextValue>(
    () => ({
      scheme,
      colors: Colors[scheme],
      preference,
      setPreference,
      cyclePreference: () => setPreference((current) => NEXT_PREFERENCE[current]),
    }),
    [scheme, preference],
  );

  return <ThemeContext value={value}>{children}</ThemeContext>;
}

export function useAppTheme(): ThemeContextValue {
  const context = use(ThemeContext);
  if (!context) {
    throw new Error('useAppTheme debe usarse dentro de <AppThemeProvider>.');
  }
  return context;
}

/**
 * Crea estilos que dependen del tema y los memoriza por esquema:
 * `const styles = useThemedStyles(createStyles)` con `createStyles = (c) => StyleSheet.create({...})`.
 */
export function useThemedStyles<T>(factory: (colors: ThemeColors) => T): T {
  const { colors } = useAppTheme();
  return useMemo(() => factory(colors), [factory, colors]);
}
