import { DarkTheme, DefaultTheme, type Theme } from 'expo-router';

import type { ColorScheme, ThemeColors } from './tokens';

/** Traduce nuestros tokens al tema de React Navigation (headers, tab bar, fondos de pantalla). */
export function buildNavigationTheme(scheme: ColorScheme, colors: ThemeColors): Theme {
  const base = scheme === 'dark' ? DarkTheme : DefaultTheme;
  return {
    ...base,
    colors: {
      ...base.colors,
      primary: colors.primary,
      background: colors.background,
      card: colors.surface,
      text: colors.text,
      border: colors.border,
      notification: colors.primary,
    },
  };
}
