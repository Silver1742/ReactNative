import { SymbolView, type SymbolViewProps } from 'expo-symbols';
import type { ColorValue } from 'react-native';

/**
 * Ícono multiplataforma: SF Symbols en iOS y Material Symbols en Android/web.
 * Recibe el nombre por plataforma porque cada set tiene su propio catálogo.
 */
export type IconName = SymbolViewProps['name'];

type IconProps = {
  name: IconName;
  color: ColorValue;
  size?: number;
};

export function Icon({ name, color, size = 22 }: IconProps) {
  return <SymbolView name={name} tintColor={color} size={size} />;
}
